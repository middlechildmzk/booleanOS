import type { ChipState, QueryVariant, SourcingMode } from "./types";

export type MemoryEvent = {
  type: string;
  roleName: string;
  mode: SourcingMode;
  selectedQuery: QueryVariant | null;
  criteria: ChipState;
  ts: string;
};

function countTerms(events: MemoryEvent[], selector: (criteria: ChipState) => string[]) {
  const counts = new Map<string, number>();
  for (const event of events) {
    for (const term of selector(event.criteria || ({} as ChipState))) {
      counts.set(term, (counts.get(term) || 0) + 1);
    }
  }
  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([term, count]) => ({ term, count }));
}

export function buildMemoryInsights(events: MemoryEvent[], mode: SourcingMode) {
  const sameMode = events.filter(e => e.mode === mode);
  const worked = sameMode.filter(e => e.type === "worked");
  const tooBroad = sameMode.filter(e => e.type === "too_broad");
  const tooNarrow = sameMode.filter(e => e.type === "too_narrow");

  const insights: string[] = [];

  if (worked.length) {
    const commonMust = countTerms(worked, c => c.must || []);
    if (commonMust.length) {
      insights.push(`Patterns that worked in ${mode}: ${commonMust.slice(0, 4).map(x => x.term).join(", ")}.`);
    }
  }

  if (tooBroad.length) {
    const commonExclusions = countTerms(tooBroad, c => c.exclusions || []);
    if (commonExclusions.length) {
      insights.push(`When searches were too broad, exclusions often mattered: ${commonExclusions.slice(0, 4).map(x => x.term).join(", ")}.`);
    } else {
      insights.push(`You marked ${tooBroad.length} ${mode} search(es) as too broad. Consider tighter exclusions or narrower title logic.`);
    }
  }

  if (tooNarrow.length) {
    insights.push(`You marked ${tooNarrow.length} ${mode} search(es) as too narrow. Consider broader titles or splitting into lanes.`);
  }

  if (!insights.length) {
    insights.push("No strong local memory pattern yet. Mark queries as worked, too broad, or too narrow to make this smarter.");
  }

  return {
    sameModeCount: sameMode.length,
    workedCount: worked.length,
    tooBroadCount: tooBroad.length,
    tooNarrowCount: tooNarrow.length,
    insights
  };
}
