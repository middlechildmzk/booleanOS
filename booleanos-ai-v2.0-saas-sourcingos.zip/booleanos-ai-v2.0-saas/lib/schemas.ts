import { z } from "zod";

export const SourcingModeSchema = z.enum([
  "General Technical",
  "AI / ML",
  "Cybersecurity",
  "Cleared / GovCon",
  "Healthcare",
  "Nursing / Allied",
  "Data Engineering",
  "Product / Design",
  "Sales / GTM"
]);

export const ChipStateSchema = z.object({
  titles: z.array(z.string()).default([]),
  must: z.array(z.string()).default([]),
  nice: z.array(z.string()).default([]),
  locations: z.array(z.string()).default([]),
  credentials: z.array(z.string()).default([]),
  companies: z.array(z.string()).default([]),
  exclusions: z.array(z.string()).default([])
});

export const QueryScoreSchema = z.object({
  coverage: z.number(),
  precision: z.number(),
  noise: z.number(),
  syntax: z.number(),
  fit: z.number()
});

export const QueryVariantSchema = z.object({
  id: z.string(),
  platform: z.string(),
  type: z.string(),
  query: z.string(),
  explanation: z.string(),
  warnings: z.array(z.string()),
  score: QueryScoreSchema
});

export const RoleStateSchema = z.object({
  mode: SourcingModeSchema,
  roleName: z.string().default(""),
  jdText: z.string().default(""),
  chips: ChipStateSchema,
  selectedQuery: QueryVariantSchema.nullish(),
  queries: z.array(QueryVariantSchema).optional()
});

export const SearchLaneSchema = z.object({
  laneName: z.string(),
  purpose: z.string(),
  titles: z.array(z.string()).default([]),
  mustHaveKeywords: z.array(z.string()).default([]),
  niceToHaveKeywords: z.array(z.string()).default([]),
  exclusions: z.array(z.string()).default([]),
  bestPlatform: z.string(),
  booleanQuery: z.string().optional(),
  whenToUse: z.string(),
  riskLevel: z.string(),
  expectedNoiseType: z.string()
});

export const AIAnalysisSchema = z.object({
  primaryTitle: z.string().default(""),
  alternateTitles: z.array(z.string()).default([]),
  seniority: z.string().default(""),
  mustHaveSkills: z.array(z.string()).default([]),
  niceToHaveSkills: z.array(z.string()).default([]),
  tools: z.array(z.string()).default([]),
  domainTerms: z.array(z.string()).default([]),
  credentials: z.array(z.string()).default([]),
  clearanceTerms: z.array(z.string()).default([]),
  locations: z.array(z.string()).default([]),
  targetCompanies: z.array(z.string()).default([]),
  exclusions: z.array(z.string()).default([]),
  noisyTermsToAvoid: z.array(z.string()).default([]),
  ambiguousRequirements: z.array(z.string()).default([]),
  searchRisks: z.array(z.string()).default([]),
  suggestedSearchLanes: z.array(SearchLaneSchema).default([]),
  confidenceScore: z.number().min(0).max(1).default(0.5)
});

export const CleanCriteriaSchema = z.object({
  chips: ChipStateSchema,
  removed: z.array(z.string()).default([]),
  notes: z.array(z.string()).default([])
});

export const QueryCritiqueSchema = z.object({
  score: z.number().default(0),
  topIssues: z.array(z.string()).default([]),
  recommendedRewrite: z.string().default(""),
  remove: z.array(z.string()).default([]),
  add: z.array(z.string()).default([]),
  splitRecommendation: z.string().default(""),
  whatToRunFirst: z.string().default(""),
  recruiterExplanation: z.string().default("")
});

export const OptimizeStateSchema = RoleStateSchema.extend({
  instruction: z.string().default("")
});
