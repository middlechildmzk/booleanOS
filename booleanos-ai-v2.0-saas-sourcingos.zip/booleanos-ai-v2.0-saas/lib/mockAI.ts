import { AIAnalysis, ChipState, RoleState, SearchLane } from "./types";
import { ONTOLOGY, LOCATION_NORMALIZATION } from "./ontology";
import { buildQueries, avgScore } from "./queryEngine";

function includesAny(text: string, terms: string[]) {
  const lower = text.toLowerCase();
  return terms.filter(t => lower.includes(t.toLowerCase()));
}

function unique(items: string[]) {
  return Array.from(new Set(items.map(x => x.trim()).filter(Boolean)));
}

export function mockAnalyzeJD(state: RoleState): AIAnalysis {
  const ont = ONTOLOGY[state.mode];
  const text = `${state.roleName} ${state.jdText}`;

  const titles = unique([state.roleName, ...includesAny(text, ont.titles)]).filter(Boolean);
  const skills = includesAny(text, ont.skills);
  const creds = includesAny(text, ont.credentials);
  const companies = includesAny(text, ["GDIT", "Booz Allen", "Leidos", "CACI", "SAIC", "Maximus", "AWS", "Microsoft", "Northrop Grumman", "Lockheed Martin"]);
  const locations = unique(Object.entries(LOCATION_NORMALIZATION).flatMap(([normalized, variants]) => {
    const found = includesAny(text, [normalized, ...variants]);
    return found.length ? [normalized] : [];
  }));

  return {
    primaryTitle: titles[0] || state.roleName || ont.titles[0],
    alternateTitles: unique([...titles.slice(1), ...ont.titles.slice(0, 4)]),
    seniority: /senior|sr\.|sr|lead|principal|staff/i.test(text) ? "Senior" : "",
    mustHaveSkills: unique(skills.slice(0, 8)),
    niceToHaveSkills: unique(ont.skills.filter(x => !skills.includes(x)).slice(0, 6)),
    tools: unique(skills.filter(x => /AWS|Azure|Kubernetes|Terraform|Docker|GitLab|Jenkins|Python|Linux|Avature|LinkedIn/i.test(x))),
    domainTerms: unique(skills.filter(x => /DoD|GovCon|RMF|ATO|FedRAMP|IC|federal/i.test(x))),
    credentials: creds,
    clearanceTerms: creds.filter(x => /Secret|TS\/SCI|Polygraph|Public Trust/i.test(x)),
    locations,
    targetCompanies: companies,
    exclusions: unique(ont.exclusions.slice(0, 6)),
    noisyTermsToAvoid: unique(["sales", "recruiter", "intern", "student", "help desk", "desktop support"].filter(x => !/sourcer|recruiter/i.test(state.roleName))),
    ambiguousRequirements: [],
    searchRisks: [
      "Avoid activating unrelated credentials from substring matches.",
      "Collapse duplicate location variants into one normalized location group.",
      "Split narrow technical requirements into multiple search lanes if volume is low."
    ],
    suggestedSearchLanes: mockGenerateLanes({
      ...state,
      chips: {
        titles: unique([titles[0] || state.roleName, ...ont.titles.slice(0, 3)]),
        must: unique(skills.slice(0, 6)),
        nice: unique(ont.skills.filter(x => !skills.includes(x)).slice(0, 5)),
        locations,
        credentials: creds,
        companies,
        exclusions: unique(ont.exclusions.slice(0, 6))
      }
    }),
    confidenceScore: 0.78
  };
}

export function mockCleanChips(state: RoleState): { chips: ChipState; removed: string[]; notes: string[] } {
  const mode = state.mode;
  const chips = JSON.parse(JSON.stringify(state.chips)) as ChipState;
  const removed: string[] = [];
  const notes: string[] = [];

  if (mode !== "Healthcare" && mode !== "Nursing / Allied") {
    chips.credentials = chips.credentials.filter(c => {
      const remove = /\bRN\b|\bLPN\b|\bBSN\b|\bMSN\b|\bBLS\b|\bCNA\b/i.test(c);
      if (remove) removed.push(c);
      return !remove;
    });
  }

  const dcTerms = ["Washington D.C.", "Washington DC", "Washington, DC", "DC Metro", "District of Columbia", "DMV"];
  const hasDC = chips.locations.some(l => dcTerms.map(x => x.toLowerCase()).includes(l.toLowerCase()));
  if (hasDC) {
    chips.locations = chips.locations.filter(l => !dcTerms.map(x => x.toLowerCase()).includes(l.toLowerCase()));
    chips.locations.unshift("Washington D.C. Metro");
    notes.push("Collapsed duplicate DC-area location variants into Washington D.C. Metro.");
  }

  if (mode === "Cleared / GovCon") {
    chips.credentials = unique([...chips.credentials, ...state.chips.credentials.filter(c => /Secret|TS\/SCI|Polygraph|Public Trust/i.test(c))]);
  }

  chips.titles = unique(chips.titles).slice(0, 8);
  chips.must = unique(chips.must).slice(0, 10);
  chips.nice = unique(chips.nice).slice(0, 10);
  chips.locations = unique(chips.locations).slice(0, 8);
  chips.credentials = unique(chips.credentials).slice(0, 8);
  chips.companies = unique(chips.companies).slice(0, 8);
  chips.exclusions = unique(chips.exclusions).slice(0, 12);

  return { chips, removed, notes };
}

export function mockGenerateLanes(state: RoleState): SearchLane[] {
  const ont = ONTOLOGY[state.mode];
  const c = state.chips;
  const titles = c.titles.length ? c.titles : [state.roleName || ont.titles[0]];

  return [
    {
      laneName: "Direct Fit",
      purpose: "Find candidates closest to the core title and must-have requirements.",
      titles: titles.slice(0, 4),
      mustHaveKeywords: c.must.slice(0, 5),
      niceToHaveKeywords: c.nice.slice(0, 3),
      exclusions: c.exclusions.slice(0, 6),
      bestPlatform: "LinkedIn Recruiter",
      booleanQuery: buildQueries(state.mode, c).find(q => q.id === "linkedin-balanced")?.query || "",
      whenToUse: "Run first to establish baseline candidate quality.",
      riskLevel: c.must.length > 7 ? "Medium: may overconstrain" : "Low",
      expectedNoiseType: "Adjacent roles missing one core keyword"
    },
    {
      laneName: "Adjacent Fit",
      purpose: "Capture strong adjacent talent with different title wording.",
      titles: unique([...titles, ...ont.titles.slice(0, 5)]),
      mustHaveKeywords: c.must.slice(0, 3),
      niceToHaveKeywords: unique([...c.nice, ...ont.skills.slice(0, 5)]),
      exclusions: c.exclusions.slice(0, 8),
      bestPlatform: "LinkedIn Recruiter",
      booleanQuery: buildQueries(state.mode, c).find(q => q.id === "linkedin-syn")?.query || "",
      whenToUse: "Use if direct-fit volume is low.",
      riskLevel: "Medium",
      expectedNoiseType: "Related profiles that are close but not exact"
    },
    {
      laneName: "Public Profile X-Ray",
      purpose: "Supplement database search with public profile discovery.",
      titles: titles.slice(0, 4),
      mustHaveKeywords: c.must.slice(0, 5),
      niceToHaveKeywords: c.credentials.slice(0, 4),
      exclusions: c.exclusions.slice(0, 8),
      bestPlatform: "Google X-Ray LinkedIn",
      booleanQuery: buildQueries(state.mode, c).find(q => q.id === "xray-linkedin")?.query || "",
      whenToUse: "Use after baseline search or when LinkedIn filters feel restrictive.",
      riskLevel: "Medium",
      expectedNoiseType: "Outdated or incomplete public profiles"
    },
    {
      laneName: "ATS Rediscovery",
      purpose: "Find past applicants and CRM records using simpler syntax.",
      titles: titles.slice(0, 4),
      mustHaveKeywords: c.must.slice(0, 4),
      niceToHaveKeywords: [],
      exclusions: c.exclusions.slice(0, 5),
      bestPlatform: "ATS / Avature",
      booleanQuery: buildQueries(state.mode, c).find(q => q.id === "ats")?.query || "",
      whenToUse: "Use for existing database rediscovery.",
      riskLevel: "Low",
      expectedNoiseType: "Keyword matches without current experience"
    }
  ];
}

export function mockCritiqueQuery(state: RoleState) {
  const q = state.selectedQuery || state.queries?.[0];
  if (!q) {
    return { score: 0, topIssues: ["No query selected."], recommendedRewrite: "", remove: [], add: [], splitRecommendation: "", whatToRunFirst: "", recruiterExplanation: "" };
  }
  const issues: string[] = [];
  if (state.chips.must.length > 7) issues.push("Many must-have chips may overconstrain narrow searches.");
  if (!state.chips.exclusions.length) issues.push("No exclusions are active, so noise risk may be higher.");
  if (state.chips.locations.length > 5) issues.push("Many location variants may duplicate the same geography.");
  if (state.mode !== "Healthcare" && state.mode !== "Nursing / Allied" && state.chips.credentials.some(c => /\bRN\b|\bLPN\b|\bBSN\b/i.test(c))) {
    issues.push("Healthcare credentials appear in a non-healthcare search.");
  }

  return {
    score: avgScore(q),
    topIssues: issues.length ? issues : ["No major issues detected."],
    recommendedRewrite: issues.length ? "Clean chips, add exclusions, and run Balanced before Narrow." : "Run this query first and save performance feedback.",
    remove: state.mode !== "Healthcare" ? state.chips.credentials.filter(c => /\bRN\b|\bLPN\b|\bBSN\b/i.test(c)) : [],
    add: !state.chips.exclusions.length ? ONTOLOGY[state.mode].exclusions.slice(0, 5) : [],
    splitRecommendation: state.chips.must.length > 7 ? "Split into Direct Fit and Adjacent Fit lanes." : "No split required yet.",
    whatToRunFirst: "Run LinkedIn Recruiter Balanced first, then switch to Broad or Narrow based on results.",
    recruiterExplanation: q.explanation
  };
}

export function mockHMMemo(state: RoleState) {
  const best = state.queries?.slice().sort((a,b)=>avgScore(b)-avgScore(a))[0];
  return `Search Strategy Memo

Role: ${state.roleName || "Untitled search"}
Mode: ${state.mode}

I will start with ${best ? `${best.platform} ${best.type}` : "a balanced LinkedIn Recruiter search"} because it offers the best balance between coverage and precision based on the confirmed search strategy.

Current title strategy:
${state.chips.titles.length ? state.chips.titles.join(", ") : "No title chips confirmed yet."}

Current must-have strategy:
${state.chips.must.length ? state.chips.must.join(", ") : "No must-have chips confirmed yet."}

Location and credential strategy:
${state.chips.locations.length ? state.chips.locations.join(", ") : "No locations confirmed."}
${state.chips.credentials.length ? state.chips.credentials.join(", ") : "No credentials confirmed."}

Noise control:
${state.chips.exclusions.length ? state.chips.exclusions.join(", ") : "No exclusions confirmed yet."}

Plan:
1. Run a balanced query first.
2. If volume is low, broaden titles and adjacent skills.
3. If results are noisy, add exclusions and use the narrow variant.
4. Use platform-specific translations for X-Ray, ClearanceJobs, and ATS rediscovery.
5. Save the best-performing query and use it as the baseline for follow-up searches.`;
}
