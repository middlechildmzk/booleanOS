import type { ChipState, QueryVariant, SearchLane, SourcingMode } from "./types";
import { getSupabaseServiceClient } from "./supabaseClient";

export type FeedbackType =
  | "worked"
  | "too_broad"
  | "too_narrow"
  | "wrong_terms"
  | "wrong_platform"
  | "never_suggest"
  | "always_include";

export type FeedbackPayload = {
  userId?: string;
  projectId?: string;
  roleName: string;
  mode: SourcingMode;
  feedbackType: FeedbackType;
  criteria: ChipState;
  selectedQuery?: QueryVariant | null;
  selectedLane?: SearchLane | null;
  term?: string;
  note?: string;
};

export async function saveFeedbackEvent(payload: FeedbackPayload) {
  const supabase = getSupabaseServiceClient();

  if (!supabase) {
    return { stored: false, reason: "Supabase not configured", payload };
  }

  const { data, error } = await supabase
    .from("feedback_events")
    .insert({
      user_id: payload.userId || null,
      project_id: payload.projectId || null,
      role_name: payload.roleName,
      mode: payload.mode,
      feedback_type: payload.feedbackType,
      criteria: payload.criteria,
      selected_query: payload.selectedQuery || null,
      selected_lane: payload.selectedLane || null,
      term: payload.term || null,
      note: payload.note || null
    })
    .select()
    .single();

  if (error) throw error;
  return { stored: true, data };
}

export async function getMemoryProfile(userId: string | undefined, mode: SourcingMode) {
  const supabase = getSupabaseServiceClient();

  if (!supabase || !userId) {
    return {
      configured: false,
      positivePatterns: [],
      negativePatterns: [],
      neverSuggestTerms: [],
      alwaysIncludeTerms: [],
      notes: ["Supabase memory is not configured yet. Using local browser memory."]
    };
  }

  const { data, error } = await supabase
    .from("feedback_events")
    .select("*")
    .eq("user_id", userId)
    .eq("mode", mode)
    .order("created_at", { ascending: false })
    .limit(200);

  if (error) throw error;

  const events = data || [];
  const positivePatterns = events
    .filter(e => e.feedback_type === "worked")
    .flatMap(e => [...(e.criteria?.must || []), ...(e.criteria?.credentials || [])])
    .slice(0, 20);

  const negativePatterns = events
    .filter(e => ["too_broad", "too_narrow", "wrong_terms", "wrong_platform"].includes(e.feedback_type))
    .map(e => e.note || e.feedback_type)
    .slice(0, 20);

  const neverSuggestTerms = events
    .filter(e => e.feedback_type === "never_suggest" && e.term)
    .map(e => e.term);

  const alwaysIncludeTerms = events
    .filter(e => e.feedback_type === "always_include" && e.term)
    .map(e => e.term);

  return {
    configured: true,
    positivePatterns: Array.from(new Set(positivePatterns)),
    negativePatterns: Array.from(new Set(negativePatterns)),
    neverSuggestTerms: Array.from(new Set(neverSuggestTerms)),
    alwaysIncludeTerms: Array.from(new Set(alwaysIncludeTerms)),
    notes: []
  };
}

export function applyMemoryToPrompt(basePrompt: string, memory: Awaited<ReturnType<typeof getMemoryProfile>>) {
  return `${basePrompt}

Memory profile:
- Positive patterns: ${memory.positivePatterns.join(", ") || "None yet"}
- Negative patterns: ${memory.negativePatterns.join(", ") || "None yet"}
- Never suggest terms: ${memory.neverSuggestTerms.join(", ") || "None yet"}
- Always include terms: ${memory.alwaysIncludeTerms.join(", ") || "None yet"}

Rules:
- Do not suggest terms listed under never suggest.
- Prefer terms listed under always include when relevant to the role and sourcing mode.
- Explain what changed because of memory when you make a recommendation.`;
}
