import type { ChipState, QueryVariant, SearchLane, SourcingMode } from "./types";

export type SourcingOSPayload = {
  projectId?: string;
  roleName: string;
  mode: SourcingMode;
  criteria: ChipState;
  lane: SearchLane;
  query?: QueryVariant | null;
  humanApproved: boolean;
};

export async function sendLaneToSourcingOS(payload: SourcingOSPayload) {
  if (!payload.humanApproved) {
    throw new Error("Human approval is required before sending to SourcingOS.");
  }

  const apiUrl = process.env.SOURCINGOS_API_URL;
  const apiKey = process.env.SOURCINGOS_API_KEY;

  if (!apiUrl || !apiKey) {
    return {
      sent: false,
      reason: "SourcingOS API is not configured yet.",
      payload
    };
  }

  const response = await fetch(`${apiUrl.replace(/\/$/, "")}/search-lanes`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    throw new Error(`SourcingOS request failed: ${response.status}`);
  }

  return {
    sent: true,
    result: await response.json()
  };
}

export function buildSourcingOSExport(payload: SourcingOSPayload) {
  return {
    type: "booleanos.search_lane",
    version: "2.0",
    exportedAt: new Date().toISOString(),
    ...payload,
    compliance: {
      humanApproved: payload.humanApproved,
      noScraping: true,
      noAutoOutreach: true,
      noProtectedTraitInference: true
    }
  };
}
