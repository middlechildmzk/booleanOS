import { SourcingMode } from "./types";

export const MODES: SourcingMode[] = [
  "General Technical",
  "AI / ML",
  "Cybersecurity",
  "Cleared / GovCon",
  "Healthcare",
  "Nursing / Allied",
  "Data Engineering",
  "Product / Design",
  "Sales / GTM"
];

export const ONTOLOGY: Record<SourcingMode, {
  titles: string[];
  skills: string[];
  exclusions: string[];
  credentials: string[];
}> = {
  "General Technical": {
    titles: ["Software Engineer", "Software Developer", "Backend Engineer", "Frontend Engineer", "Full Stack Engineer", "Systems Engineer", "Platform Engineer", "Site Reliability Engineer", "SRE", "Cloud Engineer", "DevOps Engineer"],
    skills: ["API", "REST", "GraphQL", "microservices", "cloud", "distributed systems", "SQL", "NoSQL", "CI/CD", "Docker", "Kubernetes", "AWS", "Azure", "GCP", "Java", "Python", "JavaScript", "TypeScript", "React", "Node.js", "Linux"],
    exclusions: ["recruiter", "sales", "student", "intern", "teacher", "professor"],
    credentials: []
  },
  "AI / ML": {
    titles: ["Machine Learning Engineer", "AI Engineer", "ML Engineer", "Data Scientist", "Applied Scientist", "MLOps Engineer", "LLM Engineer", "Research Engineer", "AI Researcher", "NLP Engineer"],
    skills: ["machine learning", "deep learning", "NLP", "LLM", "MLOps", "PyTorch", "TensorFlow", "vector database", "RAG", "embeddings", "LangChain", "LlamaIndex", "model deployment", "fine tuning", "Hugging Face", "OpenAI API"],
    exclusions: ["recruiter", "sales", "prompt seller", "student", "intern", "bootcamp"],
    credentials: []
  },
  "Cybersecurity": {
    titles: ["Cybersecurity Engineer", "Security Engineer", "Cloud Security Engineer", "Application Security Engineer", "AppSec Engineer", "SOC Analyst", "GRC Analyst", "Information Security Engineer"],
    skills: ["SIEM", "Splunk", "Sentinel", "vulnerability management", "RMF", "NIST", "FedRAMP", "Zero Trust", "IAM", "incident response", "threat detection", "EDR", "XDR", "penetration testing"],
    exclusions: ["physical security", "security guard", "recruiter", "sales", "student", "intern"],
    credentials: ["Security+", "CISSP", "CISM", "CEH", "GIAC"]
  },
  "Cleared / GovCon": {
    titles: ["DevSecOps Engineer", "Platform Engineer", "Cloud Engineer", "Systems Engineer", "Cybersecurity Engineer", "Software Engineer", "Site Reliability Engineer", "Cloud Security Engineer", "Linux Systems Administrator", "Systems Administrator"],
    skills: ["DoD", "IC", "federal", "GovCon", "RMF", "ATO", "NIST", "FedRAMP", "Kubernetes", "Terraform", "AWS GovCloud", "Azure Government", "Jenkins", "GitLab", "Docker", "Linux", "Ansible", "DevSecOps", "CI/CD"],
    exclusions: ["recruiter", "sales", "student", "intern", "help desk", "desktop support", "uncleared"],
    credentials: ["Secret", "Top Secret", "TS/SCI", "Polygraph", "CI Poly", "Full Scope Poly", "DoD 8570", "Security+", "Public Trust"]
  },
  "Healthcare": {
    titles: ["Healthcare Analyst", "Clinical Analyst", "Health IT Specialist", "Clinical Informatics Specialist", "Care Manager", "Provider Relations", "Medical Coder", "Case Manager"],
    skills: ["Epic", "Cerner", "EHR", "EMR", "HIPAA", "claims", "payer", "provider", "Medicaid", "Medicare", "care coordination", "utilization review"],
    exclusions: ["recruiter", "sales", "pharmaceutical sales", "student", "intern"],
    credentials: ["RHIA", "RHIT", "CCS", "CPC", "RN", "LPN", "BSN", "MSN"]
  },
  "Nursing / Allied": {
    titles: ["Registered Nurse", "RN", "Licensed Practical Nurse", "LPN", "Physical Therapist Assistant", "PTA", "Occupational Therapy Assistant", "COTA", "Radiologic Technologist", "Medical Assistant"],
    skills: ["acute care", "pediatrics", "home health", "behavioral health", "trauma-informed", "rehab", "patient care", "charting", "Epic", "BLS"],
    exclusions: ["recruiter", "sales", "student", "intern", "faculty", "instructor"],
    credentials: ["RN", "LPN", "PTA", "COTA", "BLS", "ACLS", "PALS", "ARRT", "CNA"]
  },
  "Data Engineering": {
    titles: ["Data Engineer", "Analytics Engineer", "BI Engineer", "ETL Developer", "Data Platform Engineer", "Data Warehouse Engineer", "Data Architect"],
    skills: ["SQL", "Python", "Spark", "PySpark", "Airflow", "dbt", "Snowflake", "Databricks", "Kafka", "ETL", "ELT", "data warehouse", "data lake"],
    exclusions: ["data entry", "recruiter", "sales", "student", "intern", "analyst only"],
    credentials: []
  },
  "Product / Design": {
    titles: ["Product Manager", "Senior Product Manager", "Product Owner", "Growth Product Manager", "UX Designer", "Product Designer", "UX Researcher"],
    skills: ["roadmap", "discovery", "Figma", "user research", "experimentation", "A/B testing", "SaaS", "B2B", "analytics", "design systems"],
    exclusions: ["project manager", "recruiter", "sales", "student", "intern"],
    credentials: []
  },
  "Sales / GTM": {
    titles: ["Account Executive", "Sales Development Representative", "Business Development Representative", "Customer Success Manager", "Revenue Operations", "Demand Generation Manager"],
    skills: ["SaaS", "enterprise", "pipeline", "quota", "Salesforce", "HubSpot", "Gong", "MEDDICC", "ABM", "lead generation"],
    exclusions: ["recruiter", "student", "intern", "retail sales", "cashier"],
    credentials: []
  }
};

export const LOCATION_NORMALIZATION: Record<string, string[]> = {
  "Washington D.C. Metro": ["Washington D.C.", "Washington DC", "Washington, DC", "DC Metro", "District of Columbia", "DMV"],
  "Northern Virginia": ["NoVA", "NOVA", "Virginia", "Arlington", "Alexandria", "Herndon", "Reston", "Chantilly", "McLean"],
  "Minnesota Twin Cities": ["Minneapolis", "St Paul", "Saint Paul", "Eden Prairie", "Minnetonka", "Waconia", "Chanhassen"]
};
