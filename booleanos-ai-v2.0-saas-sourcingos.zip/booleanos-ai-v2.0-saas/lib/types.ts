export type SourcingMode =
  | "General Technical"
  | "AI / ML"
  | "Cybersecurity"
  | "Cleared / GovCon"
  | "Healthcare"
  | "Nursing / Allied"
  | "Data Engineering"
  | "Product / Design"
  | "Sales / GTM";

export type ChipState = {
  titles: string[];
  must: string[];
  nice: string[];
  locations: string[];
  credentials: string[];
  companies: string[];
  exclusions: string[];
};

export type QueryScore = {
  coverage: number;
  precision: number;
  noise: number;
  syntax: number;
  fit: number;
};

export type QueryVariant = {
  id: string;
  platform: string;
  type: string;
  query: string;
  explanation: string;
  warnings: string[];
  score: QueryScore;
};

export type RoleState = {
  mode: SourcingMode;
  roleName: string;
  jdText: string;
  chips: ChipState;
  selectedQuery?: QueryVariant | null;
  queries?: QueryVariant[];
};

export type SearchLane = {
  laneName: string;
  purpose: string;
  titles: string[];
  mustHaveKeywords: string[];
  niceToHaveKeywords: string[];
  exclusions: string[];
  bestPlatform: string;
  booleanQuery?: string;
  whenToUse: string;
  riskLevel: string;
  expectedNoiseType: string;
};

export type AIAnalysis = {
  primaryTitle: string;
  alternateTitles: string[];
  seniority: string;
  mustHaveSkills: string[];
  niceToHaveSkills: string[];
  tools: string[];
  domainTerms: string[];
  credentials: string[];
  clearanceTerms: string[];
  locations: string[];
  targetCompanies: string[];
  exclusions: string[];
  noisyTermsToAvoid: string[];
  ambiguousRequirements: string[];
  searchRisks: string[];
  suggestedSearchLanes: SearchLane[];
  confidenceScore: number;
};
