export function trackEvent(eventName: string, properties: Record<string, unknown> = {}) {
  if (typeof window === "undefined") return;

  const key = process.env.NEXT_PUBLIC_POSTHOG_KEY;
  if (!key) {
    console.info("[analytics disabled]", eventName, properties);
    return;
  }

  const w = window as unknown as { posthog?: { capture: (name: string, props?: Record<string, unknown>) => void } };
  w.posthog?.capture(eventName, properties);
}
