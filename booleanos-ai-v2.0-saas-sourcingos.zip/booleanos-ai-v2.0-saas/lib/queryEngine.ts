import { ChipState, QueryVariant } from "./types";
import { ONTOLOGY } from "./ontology";
import { SourcingMode } from "./types";

function unique(items: string[]) {
  return Array.from(new Set(items.map(x => x.trim()).filter(Boolean)));
}

function quote(term: string) {
  const clean = term.trim();
  if (!clean) return "";
  return /[\s+/()]/.test(clean) && !/^".*"$/.test(clean) ? `"${clean}"` : clean;
}

function orGroup(items: string[], max = 8) {
  const arr = unique(items).slice(0, max).map(quote).filter(Boolean);
  if (!arr.length) return "";
  if (arr.length === 1) return arr[0];
  return `(${arr.join(" OR ")})`;
}

function notGroup(items: string[], google = false) {
  const arr = unique(items).slice(0, 12);
  if (!arr.length) return "";
  if (google) return arr.map(x => `-${quote(x)}`).join(" ");
  return `NOT (${arr.map(quote).join(" OR ")})`;
}

function andJoin(parts: string[]) {
  return parts.filter(Boolean).join(" AND ");
}

function validate(query: string) {
  const warnings: string[] = [];
  const open = (query.match(/\(/g) || []).length;
  const close = (query.match(/\)/g) || []).length;
  const quotes = (query.match(/"/g) || []).length;
  if (!query.trim()) warnings.push("No query generated.");
  if (open !== close) warnings.push("Parentheses may be unbalanced.");
  if (quotes % 2 !== 0) warnings.push("Quotation marks may be unbalanced.");
  if (/\b(AND|OR|NOT)\b\s+\b\1\b/i.test(query)) warnings.push("Repeated Boolean operator.");
  if (query.length > 1450) warnings.push("Long query. Some platforms may truncate it.");
  if (query.length < 20) warnings.push("Query may be too short.");
  return warnings;
}

function score(type: string, platform: string, query: string, chips: ChipState) {
  const ops = (query.match(/ OR | AND |site:|-|NOT /g) || []).length;
  const hasEx = /NOT | -/.test(query);
  const hasSite = query.includes("site:");
  const hasCred = chips.credentials.some(c => query.toLowerCase().includes(c.toLowerCase()));
  const hasLoc = chips.locations.some(l => query.toLowerCase().includes(l.toLowerCase()));
  const warnings = validate(query).length;

  let coverage = 58 + Math.min(30, ops * 2.2);
  let precision = 60 + (hasEx ? 10 : 0) + (hasCred ? 8 : 0) + (hasLoc ? 4 : 0);
  let noise = 48 - (hasEx ? 12 : 0);
  let syntax = 98 - warnings * 16;
  let fit = hasSite ? 92 : platform.includes("ATS") ? 86 : 88;

  if (type === "Broad") { coverage += 15; precision -= 8; noise += 18; }
  if (type === "Narrow") { coverage -= 10; precision += 14; noise -= 12; }
  if (type === "Synonym Expanded") { coverage += 16; precision -= 4; noise += 10; }
  if (platform.includes("ClearanceJobs") && chips.credentials.length) { precision += 10; fit += 5; }
  if (platform.includes("GitHub")) coverage += 4;
  if (!query.trim()) coverage = precision = fit = syntax = noise = 0;

  const clamp = (n: number) => Math.max(0, Math.min(99, Math.round(n)));
  return { coverage: clamp(coverage), precision: clamp(precision), noise: clamp(noise), syntax: clamp(syntax), fit: clamp(fit) };
}

export function avgScore(q: QueryVariant) {
  return Math.round((q.score.coverage + q.score.precision + (100 - q.score.noise) + q.score.syntax + q.score.fit) / 5);
}

export function buildQueries(mode: SourcingMode, chips: ChipState): QueryVariant[] {
  const i = ONTOLOGY[mode];
  const titleBroad = orGroup(chips.titles.length ? chips.titles : i.titles.slice(0, 4), 9);
  const titleTight = orGroup(chips.titles.slice(0, 4), 5);
  const mustCore = chips.must.slice(0, 6).map(x => orGroup([x], 1));
  const mustGroup = orGroup(chips.must, 12);
  const niceGroup = orGroup(chips.nice, 12);
  const credentialGroup = orGroup(chips.credentials, 9);
  const locationGroup = orGroup(chips.locations, 8);
  const companyGroup = orGroup(chips.companies, 8);
  const exclusions = notGroup(chips.exclusions, false);
  const googleExclusions = notGroup(chips.exclusions, true);
  const allSkills = unique([...chips.must, ...chips.nice]);

  const hasAny = Object.values(chips).some(arr => arr.length);
  if (!hasAny) return [];

  const raw: [string, string, string, string, string][] = [
    ["linkedin-balanced", "LinkedIn Recruiter", "Balanced", andJoin([titleBroad, ...mustCore.slice(0, 4), credentialGroup, locationGroup, exclusions]), "Best first operational search."],
    ["linkedin-broad", "LinkedIn Recruiter", "Broad", andJoin([titleBroad, orGroup(allSkills, 14), credentialGroup || locationGroup, exclusions]), "Use when the market is thin or you need adjacent candidate language."],
    ["linkedin-narrow", "LinkedIn Recruiter", "Narrow", andJoin([titleTight || titleBroad, ...mustCore.slice(0, 6), credentialGroup, locationGroup, companyGroup, exclusions]), "Use after broad searches return noise."],
    ["linkedin-syn", "LinkedIn Recruiter", "Synonym Expanded", andJoin([orGroup([...chips.titles, ...i.titles], 12), orGroup([...allSkills, ...i.skills], 18), credentialGroup, exclusions]), "Covers alternate titles and adjacent skills."],
    ["xray-linkedin", "Google X-Ray LinkedIn", "X-Ray", ["site:linkedin.com/in", orGroup([...chips.titles, ...i.titles], 10), orGroup(chips.must.length ? chips.must : i.skills.slice(0, 5), 12), credentialGroup, locationGroup, googleExclusions].filter(Boolean).join(" "), "Google X-Ray query for public LinkedIn profiles."],
    ["github-xray", "GitHub X-Ray", "X-Ray", ["site:github.com", orGroup([...chips.titles, ...i.titles], 8), orGroup([...allSkills, ...i.skills].filter(x => !/clearance|secret|rn|license|patient|clinical|recruit/i.test(x)), 14), locationGroup, googleExclusions].filter(Boolean).join(" "), "Technical and public-code discovery."],
    ["clearancejobs", "ClearanceJobs", "Balanced", andJoin([titleBroad, ...mustCore.slice(0, 4), credentialGroup || orGroup(["Secret", "Top Secret", "TS/SCI"], 3), locationGroup, notGroup(chips.exclusions.filter(x => !/uncleared/i.test(x)), false)]), "ClearanceJobs-friendly query emphasizing clearance and core terms."],
    ["dice-indeed", "Dice / Indeed", "Balanced", andJoin([titleBroad, mustGroup, locationGroup, notGroup(chips.exclusions.slice(0, 7), false)]), "Resume database style query."],
    ["ats", "ATS / Avature", "ATS", andJoin([titleBroad, ...mustCore.slice(0, 4), credentialGroup, notGroup(chips.exclusions.slice(0, 6), false)]), "Conservative syntax for ATS/CRM search."],
    ["generic", "Generic Boolean", "Balanced", andJoin([titleBroad, mustGroup || niceGroup, credentialGroup, locationGroup, exclusions]), "Reusable general-purpose Boolean string."]
  ];

  return raw.map(r => {
    const s = score(r[2], r[1], r[3], chips);
    return { id: r[0], platform: r[1], type: r[2], query: r[3], explanation: r[4], warnings: validate(r[3]), score: s };
  });
}
