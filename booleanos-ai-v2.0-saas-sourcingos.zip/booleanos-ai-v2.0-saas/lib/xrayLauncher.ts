import type { QueryVariant } from "./types";

export function isXrayQuery(query: Pick<QueryVariant, "platform" | "query" | "type">) {
  return (
    query.type.toLowerCase().includes("x-ray") ||
    query.platform.toLowerCase().includes("x-ray") ||
    query.query.includes("site:linkedin.com/in") ||
    query.query.includes("site:github.com")
  );
}

export function googleSearchUrl(queryString: string) {
  return `https://www.google.com/search?q=${encodeURIComponent(queryString)}`;
}

export function xrayLaunchUrl(query: QueryVariant) {
  return googleSearchUrl(query.query);
}
