export type AuthUser = {
  id: string;
  email?: string;
};

export function betaGateEnabled() {
  return process.env.NEXT_PUBLIC_BETA_WAITLIST_MODE === "true";
}

export function stripeEnabled() {
  return process.env.NEXT_PUBLIC_STRIPE_ENABLED === "true";
}
