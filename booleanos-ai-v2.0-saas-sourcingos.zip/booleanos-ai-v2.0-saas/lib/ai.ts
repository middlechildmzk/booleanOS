import { AIAnalysis, RoleState } from "./types";
import { mockAnalyzeJD, mockCleanChips, mockCritiqueQuery, mockGenerateLanes, mockHMMemo } from "./mockAI";
import { AIAnalysisSchema, CleanCriteriaSchema, QueryCritiqueSchema, SearchLaneSchema } from "./schemas";

const BASE_SYSTEM = `
You are BooleanOS, a recruiter search strategy copilot.
You generate search criteria, sourcing lanes, and platform-specific Boolean/X-Ray queries.
You do not scrape, collect candidates, automate outreach, or bypass platform terms.
Do not infer protected characteristics.
Do not claim clearance is verified from public data.
Use user-facing language: search criteria, requirements, filters, terms, and exclusions.
Return only valid JSON when JSON is requested.
`;

async function callModelJSON(system: string, prompt: string) {
  const apiKey = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL;

  if (!apiKey || !model) {
    return null;
  }

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model,
      input: [
        { role: "system", content: `${BASE_SYSTEM}\n${system}` },
        { role: "user", content: prompt }
      ],
      text: { format: { type: "json_object" } }
    })
  });

  if (!response.ok) {
    throw new Error(`AI request failed: ${response.status}`);
  }

  const data = await response.json();
  const text = data.output_text || data.output?.[0]?.content?.[0]?.text || "{}";
  return JSON.parse(text);
}

async function callModelText(system: string, prompt: string) {
  const apiKey = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL;

  if (!apiKey || !model) {
    return null;
  }

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model,
      input: [
        { role: "system", content: `${BASE_SYSTEM}\n${system}` },
        { role: "user", content: prompt }
      ]
    })
  });

  if (!response.ok) {
    throw new Error(`AI request failed: ${response.status}`);
  }

  const data = await response.json();
  return data.output_text || data.output?.[0]?.content?.[0]?.text || "";
}

export async function analyzeJD(state: RoleState): Promise<AIAnalysis> {
  const system = "Extract a structured sourcing profile from the role. Return JSON matching the requested schema.";
  const prompt = `Analyze this role and return a structured sourcing profile. Avoid protected traits and do not invent requirements.\n\n${JSON.stringify(state, null, 2)}`;
  const ai = await callModelJSON(system, prompt);
  const result = ai ? AIAnalysisSchema.safeParse(ai) : null;
  return result?.success ? result.data : mockAnalyzeJD(state);
}

export async function cleanChips(state: RoleState) {
  const system = "Clean the active search criteria. Return JSON with chips, removed, and notes.";
  const prompt = `Clean these search criteria. Remove unrelated terms, normalize duplicate locations, and explain what changed.\n\n${JSON.stringify(state, null, 2)}`;
  const ai = await callModelJSON(system, prompt);
  const result = ai ? CleanCriteriaSchema.safeParse(ai) : null;
  return result?.success ? result.data : mockCleanChips(state);
}

export async function generateLanes(state: RoleState) {
  const system = "Generate 3 to 5 recruiter-native sourcing lanes. Return JSON array or { lanes: [] }. ";
  const prompt = `Generate 3 to 5 sourcing search lanes for this role.\n\n${JSON.stringify(state, null, 2)}`;
  const ai = await callModelJSON(system, prompt);
  const raw = Array.isArray(ai) ? ai : ai?.lanes;
  const parsed = Array.isArray(raw) ? raw.map(x => SearchLaneSchema.safeParse(x)).filter(x => x.success).map(x => x.data) : null;
  return parsed?.length ? parsed : mockGenerateLanes(state);
}

export async function critiqueQuery(state: RoleState) {
  const system = "Audit the selected query and return JSON with score, issues, recommendations, and what to run first.";
  const prompt = `Critique the selected query and recommend changes.\n\n${JSON.stringify(state, null, 2)}`;
  const ai = await callModelJSON(system, prompt);
  const result = ai ? QueryCritiqueSchema.safeParse(ai) : null;
  return result?.success ? result.data : mockCritiqueQuery(state);
}

export async function optimizeQuery(state: RoleState & { instruction: string }) {
  const system = "Optimize this sourcing strategy. Return JSON with chips, removed, and notes.";
  const prompt = `Optimize this sourcing strategy according to the instruction: ${state.instruction}\n\n${JSON.stringify(state, null, 2)}`;
  const ai = await callModelJSON(system, prompt);
  const result = ai ? CleanCriteriaSchema.safeParse(ai) : null;
  return result?.success ? result.data : mockCleanChips(state);
}

export async function generateHMMemo(state: RoleState) {
  const system = "Write a concise, recruiter-native hiring manager search strategy memo.";
  const prompt = `Write a concise HM search strategy memo for this role.\n\n${JSON.stringify(state, null, 2)}`;
  const ai = await callModelText(system, prompt);
  return ai || mockHMMemo(state);
}
