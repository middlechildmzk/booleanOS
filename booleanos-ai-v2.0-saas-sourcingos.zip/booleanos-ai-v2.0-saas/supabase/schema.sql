-- BooleanOS v2.0 SaaS schema

create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key,
  email text,
  full_name text,
  created_at timestamptz default now()
);

create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  name text not null,
  mode text not null,
  jd_text text,
  status text default 'active',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists search_strategies (
  id uuid primary key default gen_random_uuid(),
  project_id uuid references projects(id) on delete cascade,
  user_id uuid,
  criteria jsonb not null default '{}'::jsonb,
  queries jsonb not null default '[]'::jsonb,
  lanes jsonb not null default '[]'::jsonb,
  ai_analysis jsonb,
  health jsonb,
  created_at timestamptz default now()
);

create table if not exists feedback_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  project_id uuid references projects(id) on delete cascade,
  role_name text,
  mode text not null,
  feedback_type text not null,
  criteria jsonb not null default '{}'::jsonb,
  selected_query jsonb,
  selected_lane jsonb,
  term text,
  note text,
  created_at timestamptz default now()
);

create table if not exists project_memories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  project_id uuid references projects(id) on delete cascade,
  positive_patterns jsonb not null default '[]'::jsonb,
  negative_patterns jsonb not null default '[]'::jsonb,
  never_suggest_terms jsonb not null default '[]'::jsonb,
  always_include_terms jsonb not null default '[]'::jsonb,
  platform_preferences jsonb not null default '{}'::jsonb,
  updated_at timestamptz default now()
);

create table if not exists favorite_queries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  project_id uuid references projects(id) on delete cascade,
  platform text,
  query_type text,
  query text not null,
  created_at timestamptz default now()
);

create table if not exists shared_templates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  team_id uuid,
  name text not null,
  mode text not null,
  criteria jsonb not null default '{}'::jsonb,
  lanes jsonb not null default '[]'::jsonb,
  visibility text default 'private',
  created_at timestamptz default now()
);

create table if not exists waitlist (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  name text,
  role text,
  source text,
  created_at timestamptz default now()
);

create table if not exists sourcingos_exports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  project_id uuid references projects(id) on delete set null,
  payload jsonb not null,
  status text default 'created',
  created_at timestamptz default now()
);
