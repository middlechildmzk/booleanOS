# BooleanOS Deployment Guide

## Recommended deployment

- Vercel for Next.js hosting
- Supabase for auth, saved projects, memory, waitlist
- Optional PostHog for analytics
- Optional Stripe after waitlist beta

## Local final check

```bash
npm install
npm run typecheck
npm run build
npm run dev
```

## Deploy to Vercel

1. Push this folder to GitHub.
2. Go to Vercel.
3. Import the GitHub repo.
4. Add environment variables from `.env.example`.
5. Deploy.

## Environment variables

Minimum for mock beta:

```text
NEXT_PUBLIC_APP_URL=https://your-domain.com
NEXT_PUBLIC_BETA_WAITLIST_MODE=true
```

For AI:

```text
OPENAI_API_KEY=
OPENAI_MODEL=
```

For Supabase:

```text
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

For SourcingOS integration:

```text
SOURCINGOS_API_URL=
SOURCINGOS_API_KEY=
```

## Custom domain

After deploy:
1. Open Vercel project.
2. Go to Settings > Domains.
3. Add your domain.
4. Update DNS records at your registrar.
5. Set `NEXT_PUBLIC_APP_URL` to the production domain.
6. Redeploy.

## Chrome extension production URL

Open extension settings and update app URL to the deployed BooleanOS domain.
