# BooleanOS v1.2.1 QA Checklist

## Install and build
- [ ] Fresh npm install works
- [ ] npm run build passes
- [ ] npm run dev starts
- [ ] No Tailwind/PostCSS error
- [ ] TypeScript passes with npm run typecheck
- [ ] App loads styled

## Web app workflow
- [ ] Load demo works
- [ ] Analyze Role works in mock mode
- [ ] AI Suggested Strategy Review is readable
- [ ] Approve AI Search Criteria works
- [ ] Clean Search Criteria removes wrong-mode terms
- [ ] DC/DMV/District of Columbia normalize correctly
- [ ] Query Health shows useful warnings
- [ ] Generate lanes works
- [ ] LinkedIn Recruiter query generated
- [ ] Google LinkedIn X-Ray query generated
- [ ] GitHub X-Ray query generated
- [ ] ATS/Avature conservative query generated
- [ ] Copy query works
- [ ] Run X-Ray opens Google search
- [ ] Run All X-Ray asks for confirmation
- [ ] Critique Selected Query works
- [ ] HM Memo excludes removed junk criteria
- [ ] Feedback memory persists after refresh
- [ ] Favorites persist after refresh
- [ ] Export plan works
- [ ] Export lanes works
- [ ] Export queries works
- [ ] Export HM memo works

## Extension workflow
- [ ] Extension loads unpacked
- [ ] App URL setting validates URL
- [ ] API mode works when app is running
- [ ] Local fallback works when app is offline
- [ ] Selected text context menu works
- [ ] Recent queries save
- [ ] Favorites save
- [ ] Run Google X-Ray works
- [ ] No automatic scraping
- [ ] No candidate collection
- [ ] No auto-outreach
