# BooleanOS AI Product Spec

## Product promise

BooleanOS turns a messy JD into an optimized, platform-specific sourcing strategy.

## Core AI jobs

1. Parse JD
2. Clean chips
3. Generate search lanes
4. Critique Boolean
5. Optimize query
6. Draft HM memo
7. Learn from recruiter feedback

## Why AI matters

A deterministic Boolean builder can create syntax, but it cannot reliably know which JD terms are fluff, which terms are noisy, which locations are duplicates, or when a role needs multiple search lanes.

The AI layer should act like a senior sourcer:
- Remove noise
- Normalize duplicates
- Suggest better title variants
- Split overloaded searches
- Explain tradeoffs
- Remember what worked

## Architecture

Frontend:
- Next.js
- React
- Tailwind

Backend:
- Next.js API routes

AI:
- OpenAI-compatible route abstraction
- Mock fallback

Memory:
- Local memory in v1 scaffold
- Supabase tables in production

Production:
- Auth
- Stripe
- PostHog
- Supabase
- Vercel
