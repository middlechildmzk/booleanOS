# Supabase Setup

1. Create a Supabase project.
2. Open SQL Editor.
3. Run `supabase/schema.sql`.
4. Add environment variables to Vercel.

## Tables

- profiles
- projects
- search_strategies
- feedback_events
- project_memories
- favorite_queries
- shared_templates
- waitlist
- sourcingos_exports

## RLS

Before public beta, enable RLS and add user_id policies. This scaffold keeps schema simple for local beta but should not be exposed as a multi-user production app without RLS policies.
