# BooleanOS Roadmap

## Current Build: v2.0 SaaS + SourcingOS Scaffold

This build combines:
- v1.4 AI memory and feedback scaffold
- v1.5 hosted SaaS beta scaffold
- v2.0 SourcingOS integration scaffold

## v1.4 AI Memory and Feedback — Shipped Scaffold

Included:
- Supabase schema for feedback events and project memories
- Feedback API
- Memory API
- Never suggest this again
- Always include this for cleared roles
- Positive/negative pattern extraction
- What changed because of feedback panel
- Local memory fallback

Remaining:
- Make AI prompts fully memory-aware in every endpoint
- Add user identity from Supabase Auth
- Add memory settings panel

## v1.5 Hosted SaaS Beta — Shipped Scaffold

Included:
- Supabase client scaffold
- Auth page placeholder
- Saved projects page placeholder
- Shared templates page placeholder
- Waitlist API
- Stripe checkout placeholder
- Analytics helper
- Landing page
- Privacy/compliance page
- Deployment docs

Remaining:
- Wire Supabase Auth UI
- Save projects to Supabase
- Add Stripe SDK checkout session
- Add PostHog script provider
- Add beta onboarding flow

## v2.0 SourcingOS Integration — Shipped Scaffold

Included:
- SourcingOS integration library
- SourcingOS API route
- Human approval requirement
- Export payload format
- UI panel to send approved lane

Remaining:
- Connect to real SourcingOS API
- Attach query to sourcing project
- Track query-to-candidate outcomes
- Add imported outcome feedback to memory
