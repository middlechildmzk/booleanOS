# BooleanOS X-Ray Launcher Spec

## Goal

Every X-Ray query should be directly runnable from BooleanOS.

## Behavior

- Google X-Ray LinkedIn queries open:
  `https://www.google.com/search?q=<encoded query>`

- GitHub X-Ray queries open:
  `https://www.google.com/search?q=<encoded query>`

- Generic Boolean, LinkedIn Recruiter, ATS, ClearanceJobs, Dice, and Indeed queries should be copied or searched in Google as a fallback.

## Compliance boundary

BooleanOS should not automate logged-in or restricted platforms. For LinkedIn Recruiter, ATS, ClearanceJobs, Dice, Indeed, and resume databases, the safest behavior is:

- Copy query
- Show platform instructions
- Let the recruiter paste manually

## Future version

For Chrome extension v0.2:
- Add context-menu item: “Run selected text as X-Ray”
- Add saved X-Ray launch history
- Add custom search engine choices
- Add platform presets
