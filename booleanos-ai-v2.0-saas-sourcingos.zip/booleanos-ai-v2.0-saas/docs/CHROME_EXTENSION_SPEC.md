# BooleanOS Chrome Extension v0.1 Spec

## Product intent

The extension is a safe companion for BooleanOS. It does not scrape LinkedIn profiles, automate outreach, or bypass platform rules.

It helps recruiters:
- Paste a JD
- Analyze the JD through the BooleanOS web app API
- Generate a few useful query variants
- Copy LinkedIn-style Boolean
- Open Google X-Ray
- Open the full BooleanOS web app for deeper work

## Safe boundaries

Allowed:
- User-triggered paste input
- User-triggered visible page text capture later
- Copy query
- Open Google search
- Open BooleanOS web app
- Save recent query in chrome.storage

Avoid:
- Scraping restricted platforms
- Background crawling
- Auto-collecting candidate data
- Auto-messaging
- Extracting hidden page data
- Bypassing LinkedIn, Indeed, ATS, or job board terms

## v0.1 features

- Popup UI
- JD textarea
- Mode selector
- Analyze button
- Local fallback analysis if BooleanOS API is unavailable
- Copy LinkedIn query
- Open Google X-Ray query
- Open full BooleanOS app
- Settings link for app URL

## v0.2 next

- Capture selected text on current page
- Send selected JD text to BooleanOS
- Recent searches
- Favorite queries
- App URL setting

## v0.3 next

- Google query health overlay
- Syntax warnings
- Query length warning
- Parentheses and quote validation
