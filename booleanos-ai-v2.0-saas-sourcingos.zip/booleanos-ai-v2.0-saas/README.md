# BooleanOS AI v2.0 SaaS + SourcingOS Scaffold

BooleanOS is an AI-powered sourcing query copilot for recruiters and sourcers.

This build includes:
- AI memory and feedback scaffold
- Supabase persistence schema
- Waitlist/beta gate scaffold
- Auth/saved projects/shared templates placeholders
- Analytics helper
- Stripe placeholder
- Public landing page
- Privacy/compliance page
- SourcingOS integration scaffold
- Human-approved lane export

## Quick start

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open:

```text
http://localhost:3000
```

If port 3000 is busy, Next will use 3001/3002.

## Build check

```bash
npm run typecheck
npm run build
```

## Deploy

Read:

```text
docs/DEPLOYMENT.md
```

## Safety

BooleanOS does not scrape restricted sites, auto-collect candidates, automate outreach, or infer protected traits. SourcingOS export requires human approval.
