import Link from "next/link";

export default function Page() {
  return (
    <main className="mx-auto max-w-4xl p-6">
      <section className="rounded-3xl bg-white/95 p-8 shadow-xl ring-1 ring-white">
        <h1 className="text-4xl font-black tracking-tight">Log in</h1>
        <p className="mt-4 text-slate-600">Auth scaffold placeholder. Connect Supabase Auth before hosted beta.</p>
        <Link href="/" className="mt-6 inline-flex rounded-2xl bg-slate-950 px-5 py-3 text-sm font-black text-white">Back to app</Link>
      </section>
    </main>
  );
}
