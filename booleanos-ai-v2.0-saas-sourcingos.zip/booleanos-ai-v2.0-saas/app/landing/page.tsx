import Link from "next/link";

export default function LandingPage() {
  return (
    <main className="mx-auto max-w-6xl p-6">
      <section className="rounded-3xl bg-white/95 p-10 shadow-xl ring-1 ring-white">
        <div className="inline-flex rounded-full bg-indigo-50 px-3 py-1 text-xs font-black text-indigo-700 ring-1 ring-indigo-200">BooleanOS</div>
        <h1 className="mt-5 max-w-4xl text-5xl font-black tracking-tight">The AI search strategy copilot for sourcers.</h1>
        <p className="mt-5 max-w-3xl text-lg text-slate-600">
          Turn messy role intake into approved search criteria, sourcing lanes, Boolean strings, Google X-Ray searches, query critiques, and hiring manager updates.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="/" className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-black text-white">Open App</Link>
          <Link href="/privacy" className="rounded-2xl border border-slate-300 bg-white px-5 py-3 text-sm font-black text-slate-700">Privacy & Compliance</Link>
        </div>
      </section>

      <section className="mt-6 grid gap-4 md:grid-cols-3">
        {[
          ["Search criteria", "Separate must-haves, filters, exclusions, and noisy terms."],
          ["Search lanes", "Create direct, adjacent, X-Ray, ATS, and target-company lanes."],
          ["Human-approved", "No scraping, no auto-outreach, no candidate collection."]
        ].map(([title, body]) => (
          <div key={title} className="rounded-3xl bg-white/95 p-6 shadow-xl ring-1 ring-white">
            <h2 className="text-xl font-black">{title}</h2>
            <p className="mt-2 text-slate-600">{body}</p>
          </div>
        ))}
      </section>
    </main>
  );
}
