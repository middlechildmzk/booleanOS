import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { saveFeedbackEvent } from "@/lib/memoryService";
import { ChipStateSchema, QueryVariantSchema, SearchLaneSchema, SourcingModeSchema } from "@/lib/schemas";

const FeedbackSchema = z.object({
  userId: z.string().optional(),
  projectId: z.string().optional(),
  roleName: z.string(),
  mode: SourcingModeSchema,
  feedbackType: z.enum(["worked", "too_broad", "too_narrow", "wrong_terms", "wrong_platform", "never_suggest", "always_include"]),
  criteria: ChipStateSchema,
  selectedQuery: QueryVariantSchema.nullish(),
  selectedLane: SearchLaneSchema.nullish(),
  term: z.string().optional(),
  note: z.string().optional()
});

export async function POST(req: NextRequest) {
  try {
    const body = FeedbackSchema.parse(await req.json());
    const result = await saveFeedbackEvent(body);
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }
}
