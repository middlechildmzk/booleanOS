import { NextRequest, NextResponse } from "next/server";
import { optimizeQuery } from "@/lib/ai";
import { OptimizeStateSchema } from "@/lib/schemas";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = OptimizeStateSchema.parse(body);
    const result = await optimizeQuery(parsed);
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }
}
