import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getMemoryProfile } from "@/lib/memoryService";
import { SourcingModeSchema } from "@/lib/schemas";

const MemoryRequestSchema = z.object({
  userId: z.string().optional(),
  mode: SourcingModeSchema
});

export async function POST(req: NextRequest) {
  try {
    const body = MemoryRequestSchema.parse(await req.json());
    const result = await getMemoryProfile(body.userId, body.mode);
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }
}
