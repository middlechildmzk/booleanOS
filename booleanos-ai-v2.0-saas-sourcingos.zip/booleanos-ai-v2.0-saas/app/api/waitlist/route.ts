import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSupabaseServiceClient } from "@/lib/supabaseClient";

const WaitlistSchema = z.object({
  email: z.string().email(),
  name: z.string().optional(),
  role: z.string().optional(),
  source: z.string().optional()
});

export async function POST(req: NextRequest) {
  try {
    const body = WaitlistSchema.parse(await req.json());
    const supabase = getSupabaseServiceClient();

    if (!supabase) {
      return NextResponse.json({ ok: true, result: { stored: false, reason: "Supabase not configured", body } });
    }

    const { data, error } = await supabase.from("waitlist").insert(body).select().single();
    if (error) throw error;

    return NextResponse.json({ ok: true, result: { stored: true, data } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }
}
