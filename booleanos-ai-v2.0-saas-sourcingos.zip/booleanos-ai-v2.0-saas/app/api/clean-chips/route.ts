import { NextRequest, NextResponse } from "next/server";
import { cleanChips } from "@/lib/ai";
import { RoleStateSchema } from "@/lib/schemas";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = RoleStateSchema.parse(body);
    const result = await cleanChips(parsed);
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }
}
