import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { buildSourcingOSExport, sendLaneToSourcingOS } from "@/lib/sourcingos";
import { ChipStateSchema, QueryVariantSchema, SearchLaneSchema, SourcingModeSchema } from "@/lib/schemas";

const SourcingOSSchema = z.object({
  projectId: z.string().optional(),
  roleName: z.string(),
  mode: SourcingModeSchema,
  criteria: ChipStateSchema,
  lane: SearchLaneSchema,
  query: QueryVariantSchema.nullish(),
  humanApproved: z.boolean()
});

export async function POST(req: NextRequest) {
  try {
    const body = SourcingOSSchema.parse(await req.json());
    if (!body.humanApproved) {
      return NextResponse.json({ ok: false, error: "Human approval required." }, { status: 400 });
    }
    const result = await sendLaneToSourcingOS(body);
    return NextResponse.json({ ok: true, result, exportPayload: buildSourcingOSExport(body) });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }
}
