import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  await req.json().catch(() => ({}));

  if (process.env.NEXT_PUBLIC_STRIPE_ENABLED !== "true") {
    return NextResponse.json({
      ok: true,
      result: {
        enabled: false,
        message: "Stripe is not enabled. Use waitlist mode for beta."
      }
    });
  }

  return NextResponse.json({
    ok: true,
    result: {
      enabled: true,
      message: "Stripe placeholder route. Add stripe SDK checkout session creation before public launch."
    }
  });
}
