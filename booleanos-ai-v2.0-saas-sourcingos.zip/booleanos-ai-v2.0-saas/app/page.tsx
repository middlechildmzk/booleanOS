 "use client";

import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, Brain, Clipboard, Download, ExternalLink, Sparkles, Star, Wand2, Target } from "lucide-react";
import { MODES } from "@/lib/ontology";
import { buildQueries, avgScore } from "@/lib/queryEngine";
import { isXrayQuery, xrayLaunchUrl, googleSearchUrl } from "@/lib/xrayLauncher";
import { buildMemoryInsights } from "@/lib/memoryInsights";
import { trackEvent } from "@/lib/analytics";
import type { ChipState, QueryVariant, RoleState, SearchLane, SourcingMode } from "@/lib/types";

const EMPTY_CRITERIA: ChipState = {
  titles: [],
  must: [],
  nice: [],
  locations: [],
  credentials: [],
  companies: [],
  exclusions: []
};

const CRITERIA_GROUPS: { key: keyof ChipState; label: string; placeholder: string }[] = [
  { key: "titles", label: "Target Titles", placeholder: "DevOps Engineer" },
  { key: "must", label: "Must-Have Requirements", placeholder: "Kubernetes" },
  { key: "nice", label: "Preferred Terms", placeholder: "GitLab" },
  { key: "locations", label: "Locations", placeholder: "Washington D.C. Metro" },
  { key: "credentials", label: "Clearance / Certifications", placeholder: "TS/SCI" },
  { key: "companies", label: "Target Companies", placeholder: "GDIT" },
  { key: "exclusions", label: "Exclusions", placeholder: "intern" }
];

const STARTER_JD = `Senior DevOps Engineer with active TS/SCI clearance. Washington D.C. metro area, hybrid or SCIF-required. Must have AWS GovCloud or Azure Government, Terraform, Kubernetes, Docker, CI/CD, Linux, Python or Bash, Ansible, RMF, ATO, NIST, FedRAMP, and DoD experience. Security+ or CISSP preferred.`;

type MemoryEvent = {
  type: string;
  roleName: string;
  mode: SourcingMode;
  selectedQuery: QueryVariant | null;
  criteria: ChipState;
  ts: string;
};

function unique(items: string[]) {
  return Array.from(new Set(items.map(x => String(x || "").trim()).filter(Boolean)));
}

function criteriaClass(key: keyof ChipState) {
  const map: Record<keyof ChipState, string> = {
    titles: "bg-slate-100 text-slate-700 ring-slate-200",
    must: "bg-indigo-50 text-indigo-700 ring-indigo-200",
    nice: "bg-sky-50 text-sky-700 ring-sky-200",
    locations: "bg-amber-50 text-amber-700 ring-amber-200",
    credentials: "bg-emerald-50 text-emerald-700 ring-emerald-200",
    companies: "bg-violet-50 text-violet-700 ring-violet-200",
    exclusions: "bg-rose-50 text-rose-700 ring-rose-200"
  };
  return map[key];
}

function analysisToCriteriaPreview(analysis: any): { key: keyof ChipState; label: string; values: string[] }[] {
  if (!analysis) return [];
  return [
    { key: "titles", label: "Suggested titles", values: unique([analysis.primaryTitle, ...(analysis.alternateTitles || [])]) },
    { key: "must", label: "Suggested must-haves", values: unique([...(analysis.mustHaveSkills || []), ...(analysis.tools || []), ...(analysis.domainTerms || [])]) },
    { key: "nice", label: "Suggested preferred terms", values: unique([...(analysis.niceToHaveSkills || [])]) },
    { key: "locations", label: "Location interpretation", values: unique([...(analysis.locations || [])]) },
    { key: "credentials", label: "Clearance / certification terms", values: unique([...(analysis.credentials || []), ...(analysis.clearanceTerms || [])]) },
    { key: "companies", label: "Target company ideas", values: unique([...(analysis.targetCompanies || [])]) },
    { key: "exclusions", label: "Suggested exclusions", values: unique([...(analysis.exclusions || []), ...(analysis.noisyTermsToAvoid || [])]) }
  ].filter(group => group.values.length);
}

function queryHealth(mode: SourcingMode, criteria: ChipState, queries: QueryVariant[]) {
  const issues: { level: "high" | "medium" | "low"; text: string }[] = [];
  const wins: string[] = [];

  if (!criteria.titles.length) issues.push({ level: "high", text: "No target title criteria are active." });
  else if (criteria.titles.length === 1) issues.push({ level: "medium", text: "Only one title is active. Add adjacent titles for better recall." });
  else wins.push("Title coverage looks healthy.");

  if (!criteria.must.length) issues.push({ level: "high", text: "No must-have requirements are active." });
  else if (criteria.must.length > 7) issues.push({ level: "medium", text: "Many must-have requirements may overconstrain narrow searches." });
  else wins.push("Must-have count looks usable.");

  if (!criteria.exclusions.length) issues.push({ level: "medium", text: "No exclusions are active, so false positives may be higher." });
  else wins.push("Exclusions are active.");

  if (criteria.locations.length > 5) issues.push({ level: "medium", text: "Many location variants are active. Normalize duplicates if they mean the same market." });

  const healthcareCreds = criteria.credentials.filter(c => /\b(RN|LPN|BSN|MSN|BLS|CNA)\b/i.test(c));
  if (mode !== "Healthcare" && mode !== "Nursing / Allied" && healthcareCreds.length) {
    issues.push({ level: "high", text: `Healthcare credentials appear in a non-healthcare search: ${healthcareCreds.join(", ")}.` });
  }

  if (mode === "Cleared / GovCon" && !criteria.credentials.length) {
    issues.push({ level: "high", text: "Cleared/GovCon mode has no clearance or credential criteria." });
  }

  queries.forEach(q => {
    if (q.query.length > 1200) issues.push({ level: "low", text: `${q.platform} ${q.type} query is long and may need trimming.` });
    if (q.platform.includes("ATS") && (q.query.match(/\(/g) || []).length > 4) issues.push({ level: "medium", text: "ATS query may be too complex. Use a simpler criteria set." });
  });

  return { issues, wins };
}

async function postAPI(path: string, state: unknown) {
  const res = await fetch(`/api/${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(state)
  });
  const data = await res.json();
  if (!data.ok) throw new Error(data.error || "API error");
  return data.result;
}

export default function Page() {
  const [mode, setMode] = useState<SourcingMode>("Cleared / GovCon");
  const [roleName, setRoleName] = useState("Senior DevOps Engineer");
  const [jdText, setJdText] = useState(STARTER_JD);
  const [criteria, setCriteria] = useState<ChipState>(EMPTY_CRITERIA);
  const [selectedQueryId, setSelectedQueryId] = useState<string | null>(null);
  const [aiStatus, setAiStatus] = useState("Ready");
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [lanes, setLanes] = useState<SearchLane[]>([]);
  const [critique, setCritique] = useState<any>(null);
  const [memo, setMemo] = useState("");
  const [memory, setMemory] = useState<MemoryEvent[]>([]);
  const [favorites, setFavorites] = useState<QueryVariant[]>([]);
  const [recentQueries, setRecentQueries] = useState<QueryVariant[]>([]);
  const [cloudMemory, setCloudMemory] = useState<any>(null);
  const [changeLog, setChangeLog] = useState<string[]>([]);
  const [sourcingOSStatus, setSourcingOSStatus] = useState("Not sent");
  const [waitlistEmail, setWaitlistEmail] = useState("");
  const [waitlistStatus, setWaitlistStatus] = useState("");

  const queries = useMemo(() => buildQueries(mode, criteria), [mode, criteria]);
  const selectedQuery = queries.find(q => q.id === selectedQueryId) || queries[0] || null;
  const health = useMemo(() => queryHealth(mode, criteria, queries), [mode, criteria, queries]);

  const state: RoleState = { mode, roleName, jdText, chips: criteria, selectedQuery, queries };
  const memoryInsights = useMemo(() => buildMemoryInsights(memory, mode), [memory, mode]);

  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const incomingJd = params.get("jd");
      const incomingMode = params.get("mode") as SourcingMode | null;
      const incomingRole = params.get("role");
      if (incomingJd) setJdText(incomingJd);
      if (incomingRole) setRoleName(incomingRole);
      if (incomingMode && MODES.includes(incomingMode)) setMode(incomingMode);
    } catch {}
  }, []);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("booleanos.v122.memory");
      const fav = localStorage.getItem("booleanos.v122.favorites");
      const recent = localStorage.getItem("booleanos.v122.recentQueries");
      if (saved) setMemory(JSON.parse(saved));
      if (fav) setFavorites(JSON.parse(fav));
      if (recent) setRecentQueries(JSON.parse(recent));
    } catch {}
  }, []);

  useEffect(() => { localStorage.setItem("booleanos.v122.memory", JSON.stringify(memory)); }, [memory]);
  useEffect(() => { localStorage.setItem("booleanos.v122.favorites", JSON.stringify(favorites)); }, [favorites]);
  useEffect(() => { localStorage.setItem("booleanos.v122.recentQueries", JSON.stringify(recentQueries)); }, [recentQueries]);

  function addCriteria(key: keyof ChipState, value: string) {
    if (!value.trim()) return;
    setCriteria(prev => ({ ...prev, [key]: unique([...prev[key], value]) }));
  }

  function removeCriteria(key: keyof ChipState, value: string) {
    setCriteria(prev => ({ ...prev, [key]: prev[key].filter(x => x !== value) }));
  }

  function activateAnalysis(analysis = aiAnalysis) {
    if (!analysis) return;
    const next: ChipState = {
      titles: unique([analysis.primaryTitle, ...(analysis.alternateTitles || [])]),
      must: unique([...(analysis.mustHaveSkills || []), ...(analysis.tools || []), ...(analysis.domainTerms || [])]),
      nice: unique([...(analysis.niceToHaveSkills || [])]),
      locations: unique([...(analysis.locations || [])]),
      credentials: unique([...(analysis.credentials || []), ...(analysis.clearanceTerms || [])]),
      companies: unique([...(analysis.targetCompanies || [])]),
      exclusions: unique([...(analysis.exclusions || []), ...(analysis.noisyTermsToAvoid || [])])
    };
    const changes = [
      next.titles.length ? `Approved ${next.titles.length} title criteria.` : "",
      next.must.length ? `Approved ${next.must.length} must-have criteria.` : "",
      next.exclusions.length ? `Approved ${next.exclusions.length} exclusions.` : ""
    ].filter(Boolean);
    setChangeLog(prev => [...changes, ...prev].slice(0, 12));
    setCriteria(next);
    if (analysis.primaryTitle) setRoleName(analysis.primaryTitle);
    trackEvent("criteria_approved", { mode, roleName: analysis.primaryTitle || roleName });
  }

  async function runAI(path: string, setter: (x: any) => void, label: string) {
    try {
      setAiStatus(`${label} running...`);
      const result = await postAPI(path, path === "optimize-query" ? { ...state, instruction: "Clean criteria, remove unrelated terms, normalize locations, and improve the search strategy." } : state);
      setter(result);
      setAiStatus(`${label} complete`);
      trackEvent("ai_action_complete", { label, path, mode });
    } catch (e) {
      setAiStatus(e instanceof Error ? e.message : "AI error");
    }
  }

  async function analyzeJD() { await runAI("analyze-jd", setAiAnalysis, "AI analysis"); }

  async function cleanCriteria() {
    await runAI("clean-chips", (result) => {
      if (result.chips) setCriteria(result.chips);
      const notes = [...(result.removed?.length ? [`Removed: ${result.removed.join(", ")}`] : []), ...(result.notes || [])];
      setChangeLog(prev => [...notes, ...prev].slice(0, 12));
      setAiAnalysis((prev: any) => ({ ...(prev || {}), cleanResult: result }));
    }, "Criteria cleaning");
  }

  async function generateLanes() { await runAI("generate-lanes", setLanes, "Search lanes"); }
  async function critiqueQuery() { await runAI("critique-query", setCritique, "Query critique"); }
  async function hmMemo() { await runAI("hm-memo", setMemo, "HM memo"); }

  async function logFeedback(type: string, term?: string) {
    const item: MemoryEvent = { type, roleName, mode, selectedQuery, criteria, ts: new Date().toISOString() };
    setMemory(prev => [item, ...prev].slice(0, 50));
    setChangeLog(prev => [`Feedback saved: ${type}${term ? ` (${term})` : ""}.`, ...prev].slice(0, 12));
    trackEvent("feedback_saved", { type, mode });
    try {
      await postAPI("feedback", {
        roleName,
        mode,
        feedbackType: type,
        criteria,
        selectedQuery,
        selectedLane: lanes[0] || null,
        term,
        note: type
      });
    } catch {
      // Safe fallback: local memory still works when Supabase is not configured.
    }
  }

  async function loadCloudMemory() {
    try {
      const result = await postAPI("memory", { mode });
      setCloudMemory(result);
      setChangeLog(prev => ["Loaded cloud memory profile.", ...prev].slice(0, 12));
    } catch {
      setCloudMemory({ configured: false, notes: ["Cloud memory unavailable."] });
    }
  }

  async function sendApprovedLaneToSourcingOS() {
    const lane = lanes[0];
    if (!lane) {
      setSourcingOSStatus("Generate lanes first.");
      return;
    }
    const ok = window.confirm("Send the first approved lane to SourcingOS? This is human-approved and does not collect candidates or send outreach.");
    if (!ok) return;

    try {
      const result = await postAPI("sourcingos", {
        roleName,
        mode,
        criteria,
        lane,
        query: selectedQuery,
        humanApproved: true
      });
      setSourcingOSStatus(result?.sent ? "Sent to SourcingOS." : result?.reason || "Export payload created.");
      setChangeLog(prev => ["SourcingOS export created.", ...prev].slice(0, 12));
    } catch (e) {
      setSourcingOSStatus(e instanceof Error ? e.message : "SourcingOS export failed.");
    }
  }

  async function joinWaitlist() {
    if (!waitlistEmail.trim()) {
      setWaitlistStatus("Enter an email first.");
      return;
    }

    try {
      const result = await postAPI("waitlist", { email: waitlistEmail, source: "booleanos_app", role: "recruiter" });
      setWaitlistStatus(result?.stored === false ? "Saved locally for now. Configure Supabase to store waitlist." : "You're on the waitlist.");
      setChangeLog(prev => ["Waitlist action completed.", ...prev].slice(0, 12));
    } catch (e) {
      setWaitlistStatus(e instanceof Error ? e.message : "Waitlist failed.");
    }
  }

  function loadDemo() {
    setMode("Cleared / GovCon");
    setRoleName("Senior DevOps Engineer");
    setJdText(STARTER_JD);
    setCriteria({
      titles: ["DevOps Engineer", "Site Reliability Engineer", "Platform Engineer"],
      must: ["AWS GovCloud", "Terraform", "Kubernetes", "CI/CD", "Linux", "Ansible"],
      nice: ["Docker", "GitLab", "Jenkins", "RMF", "ATO", "FedRAMP"],
      locations: ["Washington D.C. Metro", "Northern Virginia"],
      credentials: ["TS/SCI", "Top Secret", "Security+"],
      companies: ["GDIT", "Leidos", "Booz Allen", "CACI", "SAIC"],
      exclusions: ["help desk", "desktop support", "intern", "student", "sales"]
    });
  }

  function copy(text: string) { navigator.clipboard.writeText(text); }

  function runSearch(query: QueryVariant) {
    window.open(isXrayQuery(query) ? xrayLaunchUrl(query) : googleSearchUrl(query.query), "_blank", "noopener,noreferrer");
    setRecentQueries(prev => [query, ...prev.filter(q => q.query !== query.query)].slice(0, 20));
  }

  function runAllXraySearches() {
    const xrayQueries = queries.filter(q => isXrayQuery(q));
    if (!xrayQueries.length) {
      alert("No X-Ray queries generated yet.");
      return;
    }
    const ok = window.confirm(`Open ${xrayQueries.length} Google X-Ray search tab(s)?`);
    if (!ok) return;
    xrayQueries.slice(0, 5).forEach((q, index) => setTimeout(() => runSearch(q), index * 350));
  }

  function favoriteSelectedQuery() {
    if (!selectedQuery) return;
    setFavorites(prev => [selectedQuery, ...prev.filter(q => q.query !== selectedQuery.query)].slice(0, 20));
  }

  function exportMarkdown(kind: "plan" | "queries" | "memo" | "lanes") {
    let md = "";
    if (kind === "memo") md = `# HM Strategy Memo\n\n${memo || "No memo generated yet."}`;
    else if (kind === "lanes") md = `# BooleanOS Search Lanes\n\n${lanes.map(l => `## ${l.laneName}\n${l.purpose}\n\nBest platform: ${l.bestPlatform}\n\n${l.booleanQuery || ""}`).join("\n\n") || "No lanes generated yet."}`;
    else if (kind === "queries") md = `# BooleanOS Platform Queries\n\n${queries.map(q => `## ${q.platform} - ${q.type}\nScore: ${avgScore(q)}\n\n\`\`\`text\n${q.query}\n\`\`\`\n\n${q.explanation}`).join("\n\n")}`;
    else md = `# BooleanOS Search Plan\n\nRole: ${roleName}\nMode: ${mode}\n\n## JD / Notes\n${jdText}\n\n## Active Search Criteria\n${Object.entries(criteria).map(([k, v]) => `- ${k}: ${(v as string[]).join(", ") || "None"}`).join("\n")}\n\n## Query Health\n${health.issues.map(i => `- [${i.level}] ${i.text}`).join("\n") || "No major issues."}\n\n## Queries\n${queries.map(q => `### ${q.platform} - ${q.type}\n${q.query}`).join("\n\n")}\n\n## HM Memo\n${memo || "No memo generated yet."}`;

    const blob = new Blob([md], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `booleanos-${kind}.md`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main className="mx-auto max-w-7xl p-4">
      <header className="mb-5 rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <div className="inline-flex rounded-full bg-indigo-50 px-3 py-1 text-xs font-black text-indigo-700 ring-1 ring-indigo-200">BooleanOS v2.0 SaaS + SourcingOS Scaffold</div>
            <h1 className="mt-2 text-4xl font-black tracking-tight">AI Sourcing Query Copilot</h1>
            <p className="mt-2 max-w-3xl text-sm text-slate-500">
              Paste a JD, approve search criteria, get a recommended first search, generate lanes, launch X-Ray searches, critique queries, and let local memory improve the next pass.
            </p>
            <p className="mt-2 max-w-3xl text-xs font-semibold text-slate-400">Safe by design: no scraping, no automated outreach, no candidate collection, no protected-trait inference.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={loadDemo} className="rounded-2xl bg-slate-950 px-4 py-2 text-sm font-black text-white">Load demo</button>
            <button onClick={() => exportMarkdown("plan")} className="rounded-2xl border border-slate-300 bg-white px-4 py-2 text-sm font-black text-slate-700"><Download className="mr-1 inline h-4 w-4" />Export plan</button>
          </div>
        </div>
      </header>

      <section className="grid gap-4 lg:grid-cols-[390px_1fr_330px]">
        <aside className="space-y-4">
          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <h2 className="font-black">1. Intake</h2>
            <label className="mt-3 block">
              <span className="text-xs font-black uppercase text-slate-500">Mode</span>
              <select value={mode} onChange={e => setMode(e.target.value as SourcingMode)} className="mt-1 w-full rounded-2xl border border-slate-300 p-3 text-sm font-bold">
                {MODES.map(m => <option key={m}>{m}</option>)}
              </select>
            </label>
            <label className="mt-3 block">
              <span className="text-xs font-black uppercase text-slate-500">Role</span>
              <input value={roleName} onChange={e => setRoleName(e.target.value)} className="mt-1 w-full rounded-2xl border border-slate-300 p-3 text-sm" />
            </label>
            <label className="mt-3 block">
              <span className="text-xs font-black uppercase text-slate-500">JD / Notes</span>
              <textarea value={jdText} onChange={e => setJdText(e.target.value)} className="mt-1 w-full rounded-2xl border border-slate-300 p-3 text-sm" />
            </label>
            <div className="mt-4 grid gap-2">
              <button onClick={analyzeJD} className="rounded-2xl bg-indigo-600 px-4 py-2 text-sm font-black text-white"><Brain className="mr-2 inline h-4 w-4" />Analyze Role</button>
              <button onClick={() => activateAnalysis()} className="rounded-2xl bg-slate-950 px-4 py-2 text-sm font-black text-white">Approve AI Search Criteria</button>
              <button onClick={cleanCriteria} className="rounded-2xl border border-slate-300 bg-white px-4 py-2 text-sm font-black text-slate-700"><Wand2 className="mr-2 inline h-4 w-4" />Clean Search Criteria</button>
            </div>
            <div className="mt-3 rounded-2xl bg-slate-50 p-3 text-xs font-bold text-slate-600 ring-1 ring-slate-200">{aiStatus}</div>
          </div>

          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <h2 className="font-black">2. Active Search Criteria</h2>
            <div className="mt-4 space-y-4">
              {CRITERIA_GROUPS.map(group => <CriteriaEditor key={group.key} group={group} values={criteria[group.key]} onAdd={(v) => addCriteria(group.key, v)} onRemove={(v) => removeCriteria(group.key, v)} />)}
            </div>
          </div>
        </aside>

        <section className="space-y-4">
          <QueryHealthPanel health={health} />
          <RunFirstPanel queries={queries} onRunSearch={runSearch} />
          <MemoryInsightsPanel insights={memoryInsights} />

          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <div className="flex flex-col gap-2 md:flex-row md:items-start md:justify-between">
              <div>
                <h2 className="text-xl font-black">AI Suggested Strategy Review</h2>
                <p className="mt-1 text-sm text-slate-500">Review AI suggestions as recruiter search criteria. Raw JSON stays hidden unless you open the debug view.</p>
              </div>
              {aiAnalysis ? <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-black text-emerald-700 ring-1 ring-emerald-200">Analysis ready</span> : null}
            </div>
            {aiAnalysis ? <SuggestedStrategyReview analysis={aiAnalysis} onActivate={() => activateAnalysis()} onCopy={() => copy(JSON.stringify(aiAnalysis, null, 2))} /> : (
              <div className="mt-3 rounded-2xl bg-slate-50 p-4 text-sm text-slate-500 ring-1 ring-slate-200">
                Run Analyze Role to get suggested titles, must-haves, locations, credentials, exclusions, search risks, and clarification points.
              </div>
            )}
          </div>

          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-black">Search Lanes</h2>
                <p className="text-sm text-slate-500">Create strategy lanes instead of one overloaded Boolean string.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button onClick={generateLanes} className="rounded-2xl bg-slate-950 px-4 py-2 text-sm font-black text-white"><Sparkles className="mr-2 inline h-4 w-4" />Generate lanes</button>
                <button onClick={() => exportMarkdown("lanes")} className="rounded-2xl border border-slate-300 bg-white px-4 py-2 text-sm font-black text-slate-700">Export lanes</button>
              </div>
            </div>
            <div className="mt-4 grid gap-3">
              {lanes.length ? lanes.map((lane, i) => <LaneCard key={i} lane={lane} />) : <p className="text-sm text-slate-500">No lanes yet.</p>}
            </div>
          </div>

          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
              <div>
                <h2 className="text-xl font-black">Generated Queries</h2>
                <p className="mt-1 text-sm text-slate-500">Run X-Ray launches Google. Logged-in platforms remain copy/paste only.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button onClick={runAllXraySearches} className="rounded-2xl bg-indigo-600 px-4 py-2 text-sm font-black text-white"><ExternalLink className="mr-1 inline h-4 w-4" />Run All X-Ray</button>
                <button onClick={() => exportMarkdown("queries")} className="rounded-2xl border border-slate-300 bg-white px-4 py-2 text-sm font-black text-slate-700">Export queries</button>
              </div>
            </div>
            <div className="mt-4 space-y-4">
              {queries.length ? queries.map(q => <QueryCard key={q.id} query={q} selected={selectedQuery?.id === q.id} onSelect={() => setSelectedQueryId(q.id)} onRunSearch={() => runSearch(q)} onFavorite={() => {
                setSelectedQueryId(q.id);
                setFavorites(prev => [q, ...prev.filter(x => x.query !== q.query)].slice(0, 20));
              }} />) : <p className="text-sm text-slate-500">Approve search criteria to generate platform-specific queries.</p>}
            </div>
          </div>
        </section>

        <aside className="space-y-4">
          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <h2 className="font-black">3. Optimize and Learn</h2>
            <div className="mt-3 grid gap-2">
              <button onClick={critiqueQuery} className="rounded-2xl border border-slate-300 bg-white px-3 py-2 text-left text-sm font-black">Critique Selected Query</button>
              <button onClick={hmMemo} className="rounded-2xl border border-slate-300 bg-white px-3 py-2 text-left text-sm font-black">Draft HM Strategy Memo</button>
              <button onClick={favoriteSelectedQuery} className="rounded-2xl border border-slate-300 bg-white px-3 py-2 text-left text-sm font-black"><Star className="mr-1 inline h-4 w-4" />Favorite Selected Query</button>
              <button onClick={() => logFeedback("worked")} className="rounded-2xl bg-emerald-50 px-3 py-2 text-left text-sm font-black text-emerald-700 ring-1 ring-emerald-200">Worked well</button>
              <button onClick={() => logFeedback("too_broad")} className="rounded-2xl bg-amber-50 px-3 py-2 text-left text-sm font-black text-amber-700 ring-1 ring-amber-200">Too broad</button>
              <button onClick={() => logFeedback("too_narrow")} className="rounded-2xl bg-rose-50 px-3 py-2 text-left text-sm font-black text-rose-700 ring-1 ring-rose-200">Too narrow</button>
              <button onClick={() => selectedQuery && logFeedback("always_include", criteria.must[0] || criteria.credentials[0])} className="rounded-2xl bg-indigo-50 px-3 py-2 text-left text-sm font-black text-indigo-700 ring-1 ring-indigo-200">Always include top term</button>
              <button onClick={() => selectedQuery && logFeedback("never_suggest", criteria.exclusions[0] || "noise")} className="rounded-2xl bg-slate-100 px-3 py-2 text-left text-sm font-black text-slate-700 ring-1 ring-slate-200">Never suggest top exclusion</button>
            </div>
          </div>

          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <h2 className="font-black">AI Critique</h2>
            {critique ? <CritiqueCard critique={critique} /> : <p className="mt-2 text-sm text-slate-500">No critique yet.</p>}
          </div>

          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <div className="flex items-start justify-between gap-2">
              <h2 className="font-black">HM Memo</h2>
              <button onClick={() => exportMarkdown("memo")} className="rounded-xl border border-slate-300 bg-white px-2 py-1 text-xs font-black">Export</button>
            </div>
            {memo ? (
              <>
                <pre className="query-box mt-3 rounded-2xl bg-slate-50 p-4 text-xs text-slate-700 ring-1 ring-slate-200">{memo}</pre>
                <button onClick={() => copy(memo)} className="mt-3 rounded-2xl bg-slate-950 px-3 py-2 text-xs font-black text-white">Copy memo</button>
              </>
            ) : <p className="mt-2 text-sm text-slate-500">No memo yet.</p>}
          </div>


          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <h2 className="font-black">What Changed Because of Feedback</h2>
            <div className="mt-3 space-y-2">
              {changeLog.length ? changeLog.slice(0, 6).map((item, idx) => (
                <div key={idx} className="rounded-2xl bg-indigo-50 p-3 text-xs font-bold text-indigo-900 ring-1 ring-indigo-100">{item}</div>
              )) : <p className="text-sm text-slate-500">No feedback-driven changes yet.</p>}
            </div>
          </div>

          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <h2 className="font-black">Cloud Memory</h2>
            <p className="mt-2 text-sm text-slate-500">Supabase-backed memory is optional. Local memory works without setup.</p>
            <button onClick={loadCloudMemory} className="mt-3 rounded-2xl bg-slate-950 px-3 py-2 text-xs font-black text-white">Load Cloud Memory</button>
            {cloudMemory ? (
              <pre className="query-box mono mt-3 max-h-52 overflow-auto rounded-2xl bg-slate-950 p-3 text-[11px] text-slate-100">{JSON.stringify(cloudMemory, null, 2)}</pre>
            ) : null}
          </div>

          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <h2 className="font-black">SourcingOS Integration</h2>
            <p className="mt-2 text-sm text-slate-500">Send an approved search lane to SourcingOS. Human approval required.</p>
            <button onClick={sendApprovedLaneToSourcingOS} className="mt-3 rounded-2xl bg-slate-950 px-3 py-2 text-xs font-black text-white">Send Approved Lane</button>
            <p className="mt-3 rounded-2xl bg-slate-50 p-3 text-xs font-bold text-slate-600 ring-1 ring-slate-200">{sourcingOSStatus}</p>
          </div>

          <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
            <h2 className="font-black">Hosted Beta Gate</h2>
            <p className="mt-2 text-sm text-slate-500">Use waitlist mode before turning on Stripe.</p>
            <input value={waitlistEmail} onChange={e => setWaitlistEmail(e.target.value)} placeholder="email@example.com" className="mt-3 w-full rounded-2xl border border-slate-300 px-3 py-2 text-xs" />
            <button onClick={joinWaitlist} className="mt-2 rounded-2xl bg-indigo-600 px-3 py-2 text-xs font-black text-white">Join Waitlist</button>
            {waitlistStatus ? <p className="mt-2 text-xs font-bold text-slate-600">{waitlistStatus}</p> : null}
          </div>


          <MemoryPanel title="Favorites" items={favorites.map(q => ({ label: `${q.platform} · ${q.type}`, sub: q.query }))} />
          <MemoryPanel title="Recent Queries" items={recentQueries.map(q => ({ label: `${q.platform} · ${q.type}`, sub: q.query }))} />
          <MemoryPanel title="Feedback Memory" items={memory.map(m => ({ label: m.type, sub: `${m.selectedQuery?.platform || "No query"} · ${m.selectedQuery?.type || ""}` }))} />
        </aside>
      </section>
    </main>
  );
}


function DecisionCard({ title, values, tone }: { title: string; values: string[]; tone: "indigo" | "amber" | "rose" }) {
  const toneClass = {
    indigo: "bg-indigo-50 text-indigo-900 ring-indigo-100",
    amber: "bg-amber-50 text-amber-900 ring-amber-100",
    rose: "bg-rose-50 text-rose-900 ring-rose-100"
  }[tone];

  return (
    <div className={`rounded-2xl p-3 ring-1 ${toneClass}`}>
      <div className="mb-2 text-xs font-black uppercase tracking-wide opacity-70">{title}</div>
      <div className="flex flex-wrap gap-1.5">
        {values.length ? values.map(value => <span key={value} className="rounded-full bg-white/80 px-2 py-1 text-[11px] font-black ring-1 ring-white">{value}</span>) : <span className="text-xs opacity-70">No terms yet.</span>}
      </div>
    </div>
  );
}

function RunFirstPanel({ queries, onRunSearch }: { queries: QueryVariant[]; onRunSearch: (q: QueryVariant) => void }) {
  const balanced = queries.find(q => q.platform === "LinkedIn Recruiter" && q.type === "Balanced");
  const broad = queries.find(q => q.platform === "LinkedIn Recruiter" && q.type === "Broad");
  const narrow = queries.find(q => q.platform === "LinkedIn Recruiter" && q.type === "Narrow");
  const xray = queries.find(q => isXrayQuery(q));
  const first = balanced || queries.slice().sort((a,b) => avgScore(b) - avgScore(a))[0];

  return (
    <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div>
          <h2 className="flex items-center gap-2 text-xl font-black"><Target className="h-5 w-5" />Run First Recommendation</h2>
          {first ? (
            <p className="mt-1 text-sm text-slate-500">
              Start with <span className="font-black text-slate-900">{first.platform} · {first.type}</span>. It has the strongest balance of role coverage, precision, and platform fit.
            </p>
          ) : (
            <p className="mt-1 text-sm text-slate-500">Approve search criteria to get a recommended first search.</p>
          )}
        </div>
        {first ? <button onClick={() => onRunSearch(first)} className="rounded-2xl bg-slate-950 px-4 py-2 text-sm font-black text-white">{isXrayQuery(first) ? "Run X-Ray" : "Search Google"}</button> : null}
      </div>
      {queries.length ? (
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <div className="rounded-2xl bg-slate-50 p-3 ring-1 ring-slate-200">
            <div className="text-xs font-black uppercase text-slate-500">If results are thin</div>
            <p className="mt-1 text-sm font-bold text-slate-700">{broad ? "Use Broad or Synonym Expanded." : "Add title variants and adjacent skills."}</p>
          </div>
          <div className="rounded-2xl bg-slate-50 p-3 ring-1 ring-slate-200">
            <div className="text-xs font-black uppercase text-slate-500">If results are noisy</div>
            <p className="mt-1 text-sm font-bold text-slate-700">{narrow ? "Use Narrow and add exclusions." : "Tighten must-haves and exclusions."}</p>
          </div>
          <div className="rounded-2xl bg-slate-50 p-3 ring-1 ring-slate-200">
            <div className="text-xs font-black uppercase text-slate-500">If LinkedIn is weak</div>
            <p className="mt-1 text-sm font-bold text-slate-700">{xray ? "Run Google X-Ray supplement." : "Generate X-Ray queries."}</p>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function MemoryInsightsPanel({ insights }: { insights: ReturnType<typeof buildMemoryInsights> }) {
  return (
    <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div>
          <h2 className="text-xl font-black">Local Learning</h2>
          <p className="mt-1 text-sm text-slate-500">This is local memory only for now. It becomes stronger as you mark searches worked, too broad, or too narrow.</p>
        </div>
        <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-black text-slate-700 ring-1 ring-slate-200">{insights.sameModeCount} memory events</span>
      </div>
      <div className="mt-4 grid gap-3">
        {insights.insights.map((item, idx) => (
          <div key={idx} className="rounded-2xl bg-indigo-50 p-3 text-sm font-bold text-indigo-900 ring-1 ring-indigo-100">{item}</div>
        ))}
      </div>
    </div>
  );
}


function JsonDetails({ data }: { data: unknown }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-4 rounded-2xl bg-slate-50 p-3 ring-1 ring-slate-200">
      <button onClick={() => setOpen(!open)} className="text-xs font-black text-slate-700">{open ? "Hide raw AI JSON" : "Show raw AI JSON"}</button>
      {open ? <pre className="query-box mono mt-3 max-h-80 overflow-auto rounded-2xl bg-slate-950 p-4 text-xs text-slate-100">{JSON.stringify(data, null, 2)}</pre> : null}
    </div>
  );
}

function SuggestedStrategyReview({ analysis, onActivate, onCopy }: { analysis: any; onActivate: () => void; onCopy: () => void }) {
  const groups = analysisToCriteriaPreview(analysis);
  const useInSearch = unique([analysis?.primaryTitle, ...(analysis?.alternateTitles || []), ...(analysis?.mustHaveSkills || []), ...(analysis?.tools || []), ...(analysis?.domainTerms || []), ...(analysis?.clearanceTerms || [])]).slice(0, 14);
  const filterOnly = unique([...(analysis?.locations || []), ...(analysis?.credentials || []), ...(analysis?.targetCompanies || [])]).slice(0, 12);
  const avoidTerms = unique([...(analysis?.exclusions || []), ...(analysis?.noisyTermsToAvoid || [])]).slice(0, 12);
  const confidence = typeof analysis?.confidenceScore === "number" ? Math.round(analysis.confidenceScore * 100) : null;

  return (
    <div className="mt-3 space-y-4">
      <div className="rounded-2xl bg-indigo-50 p-4 ring-1 ring-indigo-100">
        <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
          <div>
            <div className="text-xs font-black uppercase tracking-wide text-indigo-500">AI Suggested Strategy</div>
            <h3 className="mt-1 text-lg font-black text-indigo-950">{analysis?.primaryTitle || "Untitled role"}</h3>
            <p className="mt-1 text-sm text-indigo-900">Review before approving. AI output does not change your search until you approve criteria.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {confidence !== null ? <span className="rounded-full bg-white px-3 py-1 text-xs font-black text-indigo-700 ring-1 ring-indigo-200">Confidence {confidence}%</span> : null}
            <button onClick={onActivate} className="rounded-2xl bg-slate-950 px-3 py-2 text-xs font-black text-white">Approve Criteria</button>
            <button onClick={onCopy} className="rounded-2xl border border-indigo-200 bg-white px-3 py-2 text-xs font-black text-indigo-700">Copy JSON</button>
          </div>
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        <DecisionCard title="Use in search" values={useInSearch} tone="indigo" />
        <DecisionCard title="Use as filters / context" values={filterOnly} tone="amber" />
        <DecisionCard title="Avoid / exclude" values={avoidTerms} tone="rose" />
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {groups.map(group => (
          <div key={group.key} className="rounded-2xl bg-slate-50 p-3 ring-1 ring-slate-200">
            <div className="mb-2 text-xs font-black uppercase tracking-wide text-slate-500">{group.label}</div>
            <div className="flex flex-wrap gap-2">
              {group.values.slice(0, 16).map(value => <span key={value} className={`rounded-full px-3 py-1 text-xs font-black ring-1 ${criteriaClass(group.key)}`}>{value}</span>)}
            </div>
          </div>
        ))}
      </div>

      {(analysis?.searchRisks?.length || analysis?.ambiguousRequirements?.length || analysis?.cleanResult) ? (
        <div className="grid gap-3 md:grid-cols-2">
          {analysis?.searchRisks?.length ? (
            <div className="rounded-2xl bg-amber-50 p-3 ring-1 ring-amber-200">
              <div className="mb-2 text-xs font-black uppercase tracking-wide text-amber-600">Search Risks</div>
              <ul className="list-disc space-y-1 pl-5 text-sm text-amber-900">{analysis.searchRisks.slice(0, 6).map((risk: string) => <li key={risk}>{risk}</li>)}</ul>
            </div>
          ) : null}
          {analysis?.ambiguousRequirements?.length ? (
            <div className="rounded-2xl bg-rose-50 p-3 ring-1 ring-rose-200">
              <div className="mb-2 text-xs font-black uppercase tracking-wide text-rose-600">Needs Clarification</div>
              <ul className="list-disc space-y-1 pl-5 text-sm text-rose-900">{analysis.ambiguousRequirements.slice(0, 6).map((item: string) => <li key={item}>{item}</li>)}</ul>
            </div>
          ) : null}
          {analysis?.cleanResult ? (
            <div className="rounded-2xl bg-emerald-50 p-3 ring-1 ring-emerald-200 md:col-span-2">
              <div className="mb-2 text-xs font-black uppercase tracking-wide text-emerald-600">Clean Criteria Changes</div>
              <p className="text-sm font-bold text-emerald-900">Removed: {analysis.cleanResult.removed?.join(", ") || "None"}</p>
              <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-emerald-900">{(analysis.cleanResult.notes || []).map((note: string) => <li key={note}>{note}</li>)}</ul>
            </div>
          ) : null}
        </div>
      ) : null}

      <JsonDetails data={analysis} />
    </div>
  );
}

function QueryHealthPanel({ health }: { health: ReturnType<typeof queryHealth> }) {
  const high = health.issues.filter(i => i.level === "high").length;
  const medium = health.issues.filter(i => i.level === "medium").length;
  const risk = high ? "High" : medium ? "Medium" : "Low";
  const riskClass = high ? "bg-rose-50 text-rose-700 ring-rose-200" : medium ? "bg-amber-50 text-amber-700 ring-amber-200" : "bg-emerald-50 text-emerald-700 ring-emerald-200";

  return (
    <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div>
          <h2 className="text-xl font-black">Query Health</h2>
          <p className="mt-1 text-sm text-slate-500">Pre-flight checks for missing anchors, overconstraint, noisy criteria, and platform complexity.</p>
        </div>
        <span className={`rounded-full px-3 py-1 text-xs font-black ring-1 ${riskClass}`}>Risk: {risk}</span>
      </div>
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <div className="rounded-2xl bg-slate-50 p-3 ring-1 ring-slate-200">
          <div className="mb-2 text-xs font-black uppercase tracking-wide text-slate-500">Issues</div>
          {health.issues.length ? <ul className="list-disc space-y-1 pl-5 text-sm text-slate-700">{health.issues.map((issue, idx) => <li key={idx}><span className="font-black">{issue.level}:</span> {issue.text}</li>)}</ul> : <p className="text-sm font-bold text-emerald-700">No major issues detected.</p>}
        </div>
        <div className="rounded-2xl bg-slate-50 p-3 ring-1 ring-slate-200">
          <div className="mb-2 text-xs font-black uppercase tracking-wide text-slate-500">What looks good</div>
          {health.wins.length ? <ul className="list-disc space-y-1 pl-5 text-sm text-slate-700">{health.wins.map((win, idx) => <li key={idx}>{win}</li>)}</ul> : <p className="text-sm text-slate-500">Approve criteria to see positive checks.</p>}
        </div>
      </div>
    </div>
  );
}

function CriteriaEditor({ group, values, onAdd, onRemove }: {
  group: { key: keyof ChipState; label: string; placeholder: string };
  values: string[];
  onAdd: (v: string) => void;
  onRemove: (v: string) => void;
}) {
  const [input, setInput] = useState("");
  return (
    <div className="rounded-2xl bg-slate-50 p-3 ring-1 ring-slate-200">
      <div className="text-xs font-black uppercase text-slate-500">{group.label}</div>
      <div className="mt-2 flex flex-wrap gap-2">
        {values.length ? values.map(v => <button key={v} onClick={() => onRemove(v)} className={`rounded-full px-3 py-1 text-xs font-black ring-1 ${criteriaClass(group.key)}`}>{v} ×</button>) : <span className="text-xs text-slate-400">None yet</span>}
      </div>
      <div className="mt-2 flex gap-2">
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => {
          if (e.key === "Enter") { e.preventDefault(); onAdd(input); setInput(""); }
        }} placeholder={group.placeholder} className="flex-1 rounded-2xl border border-slate-300 px-3 py-2 text-xs" />
        <button onClick={() => { onAdd(input); setInput(""); }} className="rounded-2xl bg-slate-950 px-3 py-2 text-xs font-black text-white">Add</button>
      </div>
    </div>
  );
}

function QueryCard({ query, selected, onSelect, onRunSearch, onFavorite }: {
  query: QueryVariant;
  selected: boolean;
  onSelect: () => void;
  onRunSearch: () => void;
  onFavorite: () => void;
}) {
  const isXray = isXrayQuery(query);
  return (
    <article onClick={onSelect} className={`cursor-pointer rounded-3xl p-5 shadow ring-1 ${selected ? "bg-indigo-50 ring-indigo-300" : "bg-white ring-slate-200"}`}>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          <span className="rounded-full bg-slate-950 px-3 py-1 text-xs font-black text-white">{query.platform}</span>
          <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-black text-slate-700">{query.type}</span>
          <span className="rounded-full bg-indigo-50 px-3 py-1 text-xs font-black text-indigo-700">Score {avgScore(query)}</span>
          {isXray ? <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-black text-emerald-700 ring-1 ring-emerald-200">Launchable X-Ray</span> : <span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-black text-amber-700 ring-1 ring-amber-200">Copy/paste platform</span>}
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(query.query); }} className="rounded-2xl bg-slate-950 px-3 py-2 text-xs font-black text-white"><Clipboard className="mr-1 inline h-3 w-3" />Copy</button>
          <button onClick={(e) => { e.stopPropagation(); onRunSearch(); }} className={`rounded-2xl px-3 py-2 text-xs font-black ${isXray ? "bg-indigo-600 text-white" : "border border-slate-300 bg-white text-slate-700"}`}>{isXray ? "Run X-Ray" : "Search Google"}</button>
          <button onClick={(e) => { e.stopPropagation(); onFavorite(); }} className="rounded-2xl border border-slate-300 bg-white px-3 py-2 text-xs font-black text-slate-700"><Star className="inline h-3 w-3" /></button>
        </div>
      </div>
      <p className="mt-2 text-sm text-slate-500">{query.explanation}</p>
      {query.warnings.length ? <div className="mt-3 rounded-2xl bg-amber-50 p-3 text-xs font-bold text-amber-900 ring-1 ring-amber-200"><AlertTriangle className="mr-1 inline h-4 w-4" />{query.warnings.join(" ")}</div> : null}
      <pre className="query-box mono mt-3 rounded-2xl bg-slate-950 p-4 text-xs text-slate-100">{query.query}</pre>
    </article>
  );
}

function LaneCard({ lane }: { lane: SearchLane }) {
  return (
    <div className="rounded-2xl bg-slate-50 p-4 ring-1 ring-slate-200">
      <div className="font-black">{lane.laneName}</div>
      <p className="mt-1 text-sm text-slate-600">{lane.purpose}</p>
      <div className="mt-2 text-xs text-slate-500">Best platform: <span className="font-black text-slate-700">{lane.bestPlatform}</span></div>
      <div className="mt-1 text-xs text-slate-500">Risk: <span className="font-black text-slate-700">{lane.riskLevel}</span></div>
      {lane.booleanQuery ? <pre className="query-box mono mt-3 rounded-xl bg-white p-3 text-xs text-slate-700 ring-1 ring-slate-200">{lane.booleanQuery}</pre> : null}
    </div>
  );
}

function CritiqueCard({ critique }: { critique: any }) {
  return (
    <div className="mt-3 space-y-3">
      <div className="rounded-2xl bg-slate-950 p-4 text-white">
        <div className="text-xs font-black uppercase tracking-wide text-slate-400">Critique score</div>
        <div className="mt-1 text-4xl font-black">{critique.score ?? 0}</div>
      </div>
      {critique.topIssues?.length ? <div className="rounded-2xl bg-amber-50 p-3 ring-1 ring-amber-200"><div className="mb-1 text-xs font-black uppercase text-amber-600">Issues</div><ul className="list-disc pl-5 text-sm text-amber-900">{critique.topIssues.map((x: string) => <li key={x}>{x}</li>)}</ul></div> : null}
      {critique.whatToRunFirst ? <p className="rounded-2xl bg-indigo-50 p-3 text-sm font-bold text-indigo-900 ring-1 ring-indigo-100">{critique.whatToRunFirst}</p> : null}
      <JsonDetails data={critique} />
    </div>
  );
}

function MemoryPanel({ title, items }: { title: string; items: { label: string; sub: string }[] }) {
  return (
    <div className="rounded-3xl bg-white/95 p-5 shadow-xl ring-1 ring-white">
      <h2 className="font-black">{title}</h2>
      <div className="mt-3 space-y-2">
        {items.length ? items.slice(0, 6).map((m, i) => <div key={i} className="rounded-2xl bg-slate-50 p-3 text-xs ring-1 ring-slate-200"><div className="font-black">{m.label}</div><div className="line-clamp-3 text-slate-500">{m.sub}</div></div>) : <p className="text-sm text-slate-500">Nothing saved yet.</p>}
      </div>
    </div>
  );
}
