import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "BooleanOS AI",
  description: "AI sourcing query copilot for recruiters and sourcers"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
