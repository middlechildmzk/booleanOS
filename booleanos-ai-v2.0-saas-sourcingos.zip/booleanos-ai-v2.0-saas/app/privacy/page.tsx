export default function PrivacyPage() {
  return (
    <main className="mx-auto max-w-4xl p-6">
      <section className="rounded-3xl bg-white/95 p-8 shadow-xl ring-1 ring-white">
        <h1 className="text-4xl font-black tracking-tight">Privacy & Compliance</h1>
        <p className="mt-4 text-slate-600">
          BooleanOS is a search strategy copilot. It helps recruiters create and evaluate search queries. It does not scrape restricted platforms, collect candidates automatically, or send outreach.
        </p>

        <div className="mt-6 space-y-5">
          <div>
            <h2 className="text-xl font-black">What BooleanOS does</h2>
            <ul className="mt-2 list-disc space-y-2 pl-5 text-slate-700">
              <li>Analyzes user-provided job descriptions and intake notes.</li>
              <li>Suggests search criteria, exclusions, and sourcing lanes.</li>
              <li>Generates Boolean and X-Ray search strings.</li>
              <li>Requires human approval before exporting or sending a search lane.</li>
            </ul>
          </div>

          <div>
            <h2 className="text-xl font-black">What BooleanOS does not do</h2>
            <ul className="mt-2 list-disc space-y-2 pl-5 text-slate-700">
              <li>No scraping LinkedIn, Indeed, ClearanceJobs, Dice, ATS systems, or logged-in platforms.</li>
              <li>No automatic candidate collection.</li>
              <li>No auto-outreach or messaging.</li>
              <li>No protected-trait inference or ranking.</li>
              <li>No claims that public text verifies clearance.</li>
            </ul>
          </div>

          <div>
            <h2 className="text-xl font-black">Human approval</h2>
            <p className="mt-2 text-slate-700">
              BooleanOS keeps recruiters in control. Search lanes, queries, exports, and SourcingOS integration actions should be reviewed and approved by a human.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
