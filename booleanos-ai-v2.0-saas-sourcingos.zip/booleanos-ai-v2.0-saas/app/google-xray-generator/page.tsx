import Link from "next/link";

export default function Page() {
  return (
    <main className="mx-auto max-w-4xl p-6">
      <section className="rounded-3xl bg-white/95 p-8 shadow-xl ring-1 ring-white">
        <div className="inline-flex rounded-full bg-indigo-50 px-3 py-1 text-xs font-black text-indigo-700 ring-1 ring-indigo-200">BooleanOS Resource</div>
        <h1 className="mt-4 text-4xl font-black tracking-tight">Google X-Ray Generator</h1>
        <p className="mt-4 text-lg text-slate-600">Create safe Google X-Ray searches for LinkedIn and GitHub public profile discovery.</p>
        <div className="mt-6 rounded-2xl bg-slate-50 p-5 ring-1 ring-slate-200">
          <h2 className="text-xl font-black">What this tool helps with</h2>
          <ul className="mt-3 list-disc space-y-2 pl-5 text-slate-700">
            <li>Extract search criteria from messy intake notes.</li>
            <li>Separate must-haves, preferred terms, filters, and exclusions.</li>
            <li>Generate platform-specific Boolean and X-Ray searches.</li>
            <li>Audit query health before running searches.</li>
          </ul>
        </div>
        <Link href="/" className="mt-6 inline-flex rounded-2xl bg-slate-950 px-5 py-3 text-sm font-black text-white">Open BooleanOS</Link>
      </section>
    </main>
  );
}
